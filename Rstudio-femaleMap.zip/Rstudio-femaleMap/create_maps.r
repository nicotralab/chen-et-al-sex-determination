#########################################################################
# Build Initial Maps                                                    #
#########################################################################

# start onemap
library(onemap)

# read in data
rawdata <- read_onemap(inputfile = "femalePT.5kb.raw")

# find bins, test segregation, do two point tests, and construct linkage groups
bins <- find_bins(rawdata, exact = FALSE)
binned_data <- create_data_bins(rawdata, bins = bins)
segreg_test <- test_segregation(binned_data)
no_dist <- select_segreg(segreg_test, distorted = FALSE, numbers = TRUE)
LOD_sug <- suggest_lod(binned_data)
twopts <- rf_2pts(binned_data, LOD = LOD_sug, max.rf = 0.4)
mark_no_dist <- make_seq(twopts, c(no_dist))
LGs <- group(mark_no_dist)

LGs

# get 16 linkage groups. group 16 is 8 markers, with 7/8 from same contig. 
# will only order the first 15.

# do initial ordering of markers.
set_map_fun("kosambi")
LG01 <- make_seq(LGs, 1)
LG02 <- make_seq(LGs, 2)
LG03 <- make_seq(LGs, 3)
LG04 <- make_seq(LGs, 4)
LG05 <- make_seq(LGs, 5)
LG06 <- make_seq(LGs, 6)
LG07 <- make_seq(LGs, 7)
LG08 <- make_seq(LGs, 8)
LG09 <- make_seq(LGs, 9)
LG10 <- make_seq(LGs, 10)
LG11 <- make_seq(LGs, 11)
LG12 <- make_seq(LGs, 12)
LG13 <- make_seq(LGs, 13)
LG14 <- make_seq(LGs, 14)
LG15 <- make_seq(LGs, 15)
LG01_ord <- order_seq(LG01, n.init = 5, THRES = 3)
LG02_ord <- order_seq(LG02, n.init = 5, THRES = 3)
LG03_ord <- order_seq(LG03, n.init = 5, THRES = 3)
LG04_ord <- order_seq(LG04, n.init = 5, THRES = 3)
LG05_ord <- order_seq(LG05, n.init = 5, THRES = 3)
LG06_ord <- order_seq(LG06, n.init = 5, THRES = 3)
LG07_ord <- order_seq(LG07, n.init = 5, THRES = 3)
LG08_ord <- order_seq(LG08, n.init = 5, THRES = 3)
LG09_ord <- order_seq(LG09, n.init = 5, THRES = 3)
LG10_ord <- order_seq(LG10, n.init = 5, THRES = 3)
LG11_ord <- order_seq(LG11, n.init = 5, THRES = 3)
LG12_ord <- order_seq(LG12, n.init = 5, THRES = 3)
LG13_ord <- order_seq(LG13, n.init = 5, THRES = 3)
LG14_ord <- order_seq(LG14, n.init = 5, THRES = 3)
LG15_ord <- order_seq(LG15, n.init = 5, THRES = 3)
LG01_all <- make_seq(LG01_ord, "force")
LG02_all <- make_seq(LG02_ord, "force")
LG03_all <- make_seq(LG03_ord, "force")
LG04_all <- make_seq(LG04_ord, "force")
LG05_all <- make_seq(LG05_ord, "force")
LG06_all <- make_seq(LG06_ord, "force")
LG07_all <- make_seq(LG07_ord, "force")
LG08_all <- make_seq(LG08_ord, "force")
LG09_all <- make_seq(LG09_ord, "force")
LG10_all <- make_seq(LG10_ord, "force")
LG11_all <- make_seq(LG11_ord, "force")
LG12_all <- make_seq(LG12_ord, "force")
LG13_all <- make_seq(LG13_ord, "force")
LG14_all <- make_seq(LG14_ord, "force")
LG15_all <- make_seq(LG15_ord, "force")


#########################################################################
# Create files for removing redundant markers                           #
#########################################################################

# NOTE---->>> need to restart R in Rstudio (the command line restart doesn't work for some reason) <<<----NOTE


options(max.print = 30000)
sink( file = "femalebins.txt")
bins
closeAllConnections()


library(onemap)
initial_maps <- list(LG01_all, LG02_all, LG03_all, LG04_all, LG05_all, LG06_all, LG07_all, LG08_all, LG09_all, LG10_all, LG11_all, LG12_all, LG13_all, LG14_all, LG15_all)
sink(file = "firstfemalemaps.txt")
initial_maps
closeAllConnections()

# Use perl script identify_redundant_markers.pl to identify markers that are within 0.00001 cM of each other.
# e.g.,




#########################################################################
# Refine LG01                                                           #
#########################################################################

rf_graph_table(LG01_all, inter = FALSE, main = "LG01 - initial map")

#remove redundant markers
LG01_test_seq <- drop_marker(LG01_all, c(579,577,575,573,570,503,501,498,497,495,492,490,489,486,485,5,7,10,15,17,20,21,24,761,759,710,707))
(LG01_test_map <- map(LG01_test_seq))
# log likelihood now still -746.4966

#drop marker 480 
LG01_test_seq <- drop_marker(LG01_test_seq, c(480))
(LG01_test_map <- map(LG01_test_seq))
rf_graph_table(LG01_test_map, inter = FALSE, main = "LG01 - initial map")
#likelihood now -700.400

#drop marker 13 (has missing data)
LG01_test_seq <- drop_marker(LG01_test_seq, c(13))
(LG01_test_map <- map(LG01_test_seq))
rf_graph_table(LG01_test_map, inter = FALSE, main = "LG01 - initial map")
#likelihood now -671.4901

#drop marker 767 (single marker bin in middle of well represented contig)
LG01_test_seq <- drop_marker(LG01_test_seq, c(767))
(LG01_test_map <- map(LG01_test_seq))
rf_graph_table(LG01_test_map, inter = FALSE, main = "LG01 - initial map")
#likelihood now -634.8035

#drop markers 581, 582, 766
#these markers are single bins in middle of well represented contigs - could be double recombinants
LG01_test_seq <- drop_marker(LG01_test_seq, c(581,582, 766))
(LG01_test_map <- map(LG01_test_seq))
rf_graph_table(LG01_test_map, inter = FALSE, main = "LG01 - initial map")
#likelihood now -556.6698

# try to reposition 585 and 584
LG01_test_seq <- drop_marker(LG01_test_seq, c(585,584))
(LG01_test_map <- map(LG01_test_seq))

LG01_try <- try_seq(LG01_test_map, 584)
LG01_try
LG01_test_map <-make_seq(LG01_try, 7)


LG01_try <- try_seq(LG01_test_map, 585)
LG01_try
# puts it in same place. 585 is single marker bin with 2 missing datapoints. Will not put back in
rf_graph_table(LG01_test_map, inter = FALSE, main = "LG01 - initial map")

#markers at far end of linkage group could be rearranged better, I think. 
LG01_test_seq <- drop_marker(LG01_test_seq, c(768, 769, 765, 764, 763, 760, 762, 758, 712, 757, 711, 708, 709, 63))
(LG01_test_map <- map(LG01_test_seq))
rf_graph_table(LG01_test_map, inter = FALSE, main = "LG01")


LG01_try <- try_seq(LG01_test_map, 708)
LG01_try
LG01_test_map <- make_seq(LG01_try, 43)

LG01_try <- try_seq(LG01_test_map, 709)
LG01_try
LG01_test_map <- make_seq(LG01_try, 43)

LG01_try <- try_seq(LG01_test_map, 711)
LG01_try
LG01_test_map <- make_seq(LG01_try, 43)

LG01_try <- try_seq(LG01_test_map, 712)
LG01_try
LG01_test_map <- make_seq(LG01_try, 43)

LG01_try <- try_seq(LG01_test_map, 757)
LG01_try
LG01_test_map <- make_seq(LG01_try, 44)

LG01_try <- try_seq(LG01_test_map, 758)
LG01_try
LG01_test_map <- make_seq(LG01_try, 43)

LG01_try <- try_seq(LG01_test_map, 760)
LG01_try
LG01_test_map <- make_seq(LG01_try, 43)

LG01_try <- try_seq(LG01_test_map, 764)
LG01_try
LG01_test_map <- make_seq(LG01_try, 43)

LG01_try <- try_seq(LG01_test_map, 768)
LG01_try
LG01_test_map <- make_seq(LG01_try, 43)


LG01_try <- try_seq(LG01_test_map, 765)
LG01_try
LG01_test_map <- make_seq(LG01_try, 44)

LG01_try <- try_seq(LG01_test_map, 769)
LG01_try
LG01_test_map <- make_seq(LG01_try, 44)

rf_graph_table(LG01_test_map, inter = FALSE, main = "LG01")

# 16 is single marker bin out of ordrer with contig.
LG01_test_seq <- drop_marker(LG01_test_seq, c(16))
(LG01_test_map <- map(LG01_test_seq))
rf_graph_table(LG01_test_map, inter = FALSE, main = "LG01")


LG01_final <- LG01_test_map

#########################################################################
# Refine LG02                                                           #
#########################################################################

LG02_all
#likelihood of this map is -642

#remove redundant markers
LG02_test_seq <- drop_marker(LG02_all, c(726,476,471,469,465,464,460,242,241,236,233,230,229,227,224,333,332,327,325,321,318))
(LG02_test_map <- map(LG02_test_seq))
# log likelihood now still -642.3206

rf_graph_table(LG02_test_map, inter = FALSE, main = "LG02")

#drop makrer 225
LG02_test_seq <- drop_marker(LG02_test_map, c(225))
(LG02_test_map <- map(LG02_test_seq))
# log likelihood now -604.21

rf_graph_table(LG02_test_map, inter = FALSE, main = "LG02")

# drop marker 329, which is single marker bin with 2 missing data points
LG02_test_seq <- drop_marker(LG02_test_map, c(329))
(LG02_test_map <- map(LG02_test_seq))

# drop marker 246, which is single marker bin with 6 missind data points
LG02_test_seq <- drop_marker(LG02_test_map, c(246))
(LG02_test_map <- map(LG02_test_seq))

# drop marker 237, which is single marker bin with 9 missind data points
LG02_test_seq <- drop_marker(LG02_test_map, c(237))
(LG02_test_map <- map(LG02_test_seq))


# drop 324, single marker 3 missing datapoints, 
LG02_test_seq <- drop_marker(LG02_test_map, c(324))
(LG02_test_map <- map(LG02_test_seq))

rf_graph_table(LG02_test_map, inter = FALSE, main = "LG02")

# now rearrange end with 316 through 328
LG02_test_seq <- drop_marker(LG02_test_map, c(328, 326, 319, 322, 320, 323, 315, 314, 313, 316))
(LG02_test_map <- map(LG02_test_seq))
#316, 319, 322, 323 single marker bins from within larger contig, not replaced


LG02_try <- try_seq(LG02_test_map, 313)
LG02_try
LG02_test_map <- make_seq(LG02_try, 37)

LG02_try <- try_seq(LG02_test_map, 314)
LG02_try
LG02_test_map <- make_seq(LG02_try, 37)

LG02_try <- try_seq(LG02_test_map, 315)
LG02_try
LG02_test_map <- make_seq(LG02_try, 37)

LG02_try <- try_seq(LG02_test_map, 320)
LG02_try
LG02_test_map <- make_seq(LG02_try, 37)

LG02_try <- try_seq(LG02_test_map, 326)
LG02_try
LG02_test_map <- make_seq(LG02_try, 37)

LG02_try <- try_seq(LG02_test_map, 328)
LG02_try
LG02_test_map <- make_seq(LG02_try, 37)

rf_graph_table(LG02_test_map, inter = FALSE, main = "LG02")

#reposition middle markers
LG02_test_seq <- drop_marker(LG02_test_map, c(244, 245, 243, 240, 239, 235, 238, 232, 231, 228, 226, 223))
(LG02_test_map <- map(LG02_test_seq))

LG02_try <- try_seq(LG02_test_map, 223)
LG02_try
LG02_test_map <- make_seq(LG02_try, 22)

LG02_try <- try_seq(LG02_test_map, 226)
LG02_try
LG02_test_map <- make_seq(LG02_try, 22)

LG02_try <- try_seq(LG02_test_map, 228)
LG02_try
LG02_test_map <- make_seq(LG02_try, 22)

LG02_try <- try_seq(LG02_test_map, 231)
LG02_try
LG02_test_map <- make_seq(LG02_try, 22)

LG02_try <- try_seq(LG02_test_map, 232)
LG02_try
LG02_test_map <- make_seq(LG02_try, 22)

LG02_try <- try_seq(LG02_test_map, 235)
LG02_try
LG02_test_map <- make_seq(LG02_try, 22)

LG02_try <- try_seq(LG02_test_map, 240)
LG02_try
LG02_test_map <- make_seq(LG02_try, 22)

LG02_try <- try_seq(LG02_test_map, 243)
LG02_try
LG02_test_map <- make_seq(LG02_try, 22)

LG02_try <- try_seq(LG02_test_map, 244)
LG02_try
LG02_test_map <- make_seq(LG02_try, 22)

LG02_try <- try_seq(LG02_test_map, 245)
LG02_try
LG02_test_map <- make_seq(LG02_try, 22)

LG02_test_map

rf_graph_table(LG02_test_map, inter = FALSE, main = "LG02")


LG02_final <- LG02_test_map



#########################################################################
# Refine LG03                                                           #
#########################################################################

LG03_all
#likelihood of this map is -649

#remove redundant markers
LG03_test_seq <- drop_marker(LG03_all, c(803,800,799,26,27,29,32,34,37,40,43,45,51,57,59,564,562,560,544,545,547,549))
(LG03_test_map <- map(LG03_test_seq))
# log likelihood now still -649.8895

rf_graph_table(LG03_test_map, inter = FALSE, main = "LG03")


#marker 53, 54, 62, 806, 30, 39, 49, 551 are all single marker bins with missing data. They will be dropped.
LG03_test_seq <- drop_marker(LG03_test_map, c(53, 54, 62, 806, 30, 39, 49, 551))
(LG03_test_map <- map(LG03_test_seq))
# now -535.6044
rf_graph_table(LG03_test_map, inter = FALSE, main = "LG03")

# reorder markers 48, which is redundant to 47
LG03_test_seq <- drop_marker(LG03_test_map, c(48))
(LG03_test_map <- map(LG03_test_seq))
LG03_try <- try_seq(LG03_test_map, 48)
LG03_try
LG03_test_map <- make_seq(LG03_try, 18)
rf_graph_table(LG03_test_map, inter = FALSE, main = "LG03")

# reorder markers at end.
LG03_test_seq <- drop_marker(LG03_test_map, c(541, 542, 543, 546, 548, 550, 552, 553))
(LG03_test_map <- map(LG03_test_seq))

LG03_try <- try_seq(LG03_test_map, 541)
LG03_try
LG03_test_map <- make_seq(LG03_try, 37)

LG03_try <- try_seq(LG03_test_map, 542)
LG03_try
LG03_test_map <- make_seq(LG03_try, 37)

LG03_try <- try_seq(LG03_test_map, 543)
LG03_try
LG03_test_map <- make_seq(LG03_try, 37)

LG03_try <- try_seq(LG03_test_map, 546)
LG03_try
LG03_test_map <- make_seq(LG03_try, 37)

LG03_try <- try_seq(LG03_test_map, 548)
LG03_try
LG03_test_map <- make_seq(LG03_try, 37)

LG03_try <- try_seq(LG03_test_map, 550)
LG03_try
LG03_test_map <- make_seq(LG03_try, 37)

LG03_try <- try_seq(LG03_test_map, 552)
LG03_try
LG03_test_map <- make_seq(LG03_try, 37)

LG03_try <- try_seq(LG03_test_map, 553)
LG03_try
LG03_test_map <- make_seq(LG03_try, 37)

rf_graph_table(LG03_test_map, inter = FALSE, main = "LG03")

# marker 568 single marker bin out of order with contig. 
LG03_test_seq <- drop_marker(LG03_test_map, c(568))
(LG03_test_map <- map(LG03_test_seq))
rf_graph_table(LG03_test_map, inter = FALSE, main = "LG03")



LG03_final <- LG03_test_map

#########################################################################
# Refine LG04                                                           #
#########################################################################

LG04_all
#likelihood of this map is -817.1888

#remove redundant markers
LG04_test_seq <- drop_marker(LG04_all, c(282,288,291,292,294,298,301,303,305,306,309,844,842,841,67,70,71,76,79,95,98,99,103,74))
(LG04_test_map <- map(LG04_test_seq))
# log likelihood now -817.1646

rf_graph_table(LG04_test_map, inter = FALSE, main = "LG04")

#marker 84,957,296,299 single marker bin with missind data. 
LG04_test_seq <- drop_marker(LG04_test_map, c(84,957,296,299))
(LG04_test_map <- map(LG04_test_seq))
# loke likelihood now -669.2301

#marker 66,91,975,308,284,959  single marker bins, no missing data. 
LG04_test_seq <- drop_marker(LG04_test_map, c(66,91,975,308, 284,959))
(LG04_test_map <- map(LG04_test_seq))
rf_graph_table(LG04_test_map, inter = FALSE, main = "LG04")
  
#reorder one end
LG04_test_seq <- drop_marker(LG04_test_map, c(81, 83, 87, 93, 94, 96, 97, 100, 101, 102, 105, 106, 107, 108))
(LG04_test_map <- map(LG04_test_seq))

#markers 101,107,108 and 87 are single bin markers that end up out of order with respect to rest of multimarker bins in their contig. Removed


LG04_try <- try_seq(LG04_test_map, 81)
LG04_try
LG04_test_map <- make_seq(LG04_try, 33)

LG04_try <- try_seq(LG04_test_map, 83)
LG04_try
LG04_test_map <- make_seq(LG04_try, 34)

LG04_try <- try_seq(LG04_test_map, 93)
LG04_try
LG04_test_map <- make_seq(LG04_try, 35)

LG04_try <- try_seq(LG04_test_map, 94)
LG04_try
LG04_test_map <- make_seq(LG04_try, 36)

LG04_try <- try_seq(LG04_test_map, 96)
LG04_try
LG04_test_map <- make_seq(LG04_try, 37)

LG04_try <- try_seq(LG04_test_map, 97)
LG04_try
LG04_test_map <- make_seq(LG04_try, 38)

LG04_try <- try_seq(LG04_test_map, 100)
LG04_try
LG04_test_map <- make_seq(LG04_try, 39)

LG04_try <- try_seq(LG04_test_map, 102)
LG04_try
LG04_test_map <- make_seq(LG04_try, 40)

LG04_try <- try_seq(LG04_test_map, 105)
LG04_try
LG04_test_map <- make_seq(LG04_try, 41)

LG04_try <- try_seq(LG04_test_map, 106)
LG04_try
LG04_test_map <- make_seq(LG04_try, 42)

LG04_test_map
rf_graph_table(LG04_test_map, inter = FALSE, main = "LG04")

# marker 96 single marker bin out of order with contig.
# marker 846 single marker bin with 2 missind data points.
LG04_test_seq <- drop_marker(LG04_test_map, c(96, 846))
(LG04_test_map <- map(LG04_test_seq))
rf_graph_table(LG04_test_map, inter = FALSE, main = "LG04")

LG04_final <- LG04_test_map


#########################################################################
# Refine LG05                                                           #
#########################################################################

LG05_all
# log likelihood -670.7033

#no redundant markers

# 970, 432, 439, 692,  all single marker with missing data.
# dropped them
LG05_test_seq <- drop_marker(LG05_all, c(970, 432, 439, 692))
(LG05_test_map <- map(LG05_test_seq))
# log likelihood now -530.4511

rf_graph_table(LG05_test_map, inter = FALSE, main = "LG05")

#markers at end are in wrong order.
LG05_test_seq <- drop_marker(LG05_test_map, c(438, 440, 441, 442, 443, 444, 445, 446, 447, 448, 450))
(LG05_test_map <- map(LG05_test_seq))

#444 and 445, 447 are single marker bins out of order with respect to multmarker bins in same contig. Won't replace them.
LG05_try <- try_seq(LG05_test_map, 438)
LG05_try
LG05_test_map <- make_seq(LG05_try, 1)

LG05_try <- try_seq(LG05_test_map, 440)
LG05_try
LG05_test_map <- make_seq(LG05_try, 1)

LG05_try <- try_seq(LG05_test_map, 441)
LG05_try
LG05_test_map <- make_seq(LG05_try, 1)

LG05_try <- try_seq(LG05_test_map, 442)
LG05_try
LG05_test_map <- make_seq(LG05_try, 1)

LG05_try <- try_seq(LG05_test_map, 443)
LG05_try
LG05_test_map <- make_seq(LG05_try, 1)

LG05_try <- try_seq(LG05_test_map, 446)
LG05_try
LG05_test_map <- make_seq(LG05_try, 1)


LG05_try <- try_seq(LG05_test_map, 448)
LG05_try
LG05_test_map <- make_seq(LG05_try, 1)

LG05_try <- try_seq(LG05_test_map, 450)
LG05_try
LG05_test_map <- make_seq(LG05_try, 1)

rf_graph_table(LG05_test_map, inter = FALSE, main = "LG05")
LG05_test_map

# 694 single marker out of order with rest of contig. 
LG05_test_seq <- drop_marker(LG05_test_map, c(694))
(LG05_test_map <- map(LG05_test_seq))

rf_graph_table(LG05_test_map, inter = FALSE, main = "LG05")

LG05_final <- LG05_test_map

#########################################################################
# Refine LG06                                                           #
#########################################################################

LG06_all


#remove redundant marker
LG06_test_seq <- drop_marker(LG06_all, c(595))
(LG06_test_map <- map(LG06_test_seq))
# log likelihood now -653.018

rf_graph_table(LG06_test_map, inter = FALSE, main = "LG06")

#368, 455, 367, 368, 951 single marker bin out of place with rest of contig. 
LG06_test_seq <- drop_marker(LG06_test_map, c(455, 367, 951, 368, 367))
(LG06_test_map <- map(LG06_test_seq))
rf_graph_table(LG06_test_map, inter = FALSE, main = "LG06", graph.LOD = FALSE)

LG06_final <- LG06_test_map


#########################################################################
# Refine LG07                                                           #
#########################################################################

LG07_all


#remove redundant marker
LG07_test_seq <- drop_marker(LG07_all, c(401,403,406,408,400,397,392,391,135,136,139,140,142,144,147))
(LG07_test_map <- map(LG07_test_seq))
# log likelihood now -746.0915

rf_graph_table(LG07_test_map, inter = FALSE, main = "LG07", graph.LOD = FALSE)

#152, 963, 148, 909 single marker bin with missing data. 
# 161 single marker bin out of order with rest of contig.
LG07_test_seq <- drop_marker(LG07_test_map, c(152, 963, 148, 909, 161))
(LG07_test_map <- map(LG07_test_seq))
rf_graph_table(LG07_test_map, inter = FALSE, main = "LG07", graph.LOD = FALSE)

LG07_final <- LG07_test_map

#########################################################################
# Refine LG08                                                           #
#########################################################################

LG08_all


#remove redundant marker
LG08_test_seq <- drop_marker(LG08_all, c(206,201,556,558,163,166,167,172,173,176,178,180,183,186,188,190,191,196,198))
(LG08_test_map <- map(LG08_test_seq))
# log likelihood now -739.6985

rf_graph_table(LG08_test_map, inter = FALSE, main = "LG08", graph.LOD = FALSE)



# 962, 559,195,197, 968 single marker bin with missing data. 
LG08_test_seq <- drop_marker(LG08_test_map, c(962,559,195,197, 968))
(LG08_test_map <- map(LG08_test_seq))

rf_graph_table(LG08_test_map, inter = FALSE, main = "LG08", graph.LOD = FALSE)

#177, 181, 184 single marker bin out of order with multimarker bins from same contig.
LG08_test_seq <- drop_marker(LG08_test_map, c(177, 181, 184))
(LG08_test_map <- map(LG08_test_seq))

#973 is single marker bin from small contig with only one marker in all of dataset.
LG08_test_seq <- drop_marker(LG08_test_map, c(973))
(LG08_test_map <- map(LG08_test_seq))

# resposition one side:
LG08_test_seq <- drop_marker(LG08_test_map, c(164, 165, 168, 169, 170, 171, 174, 175, 179, 182, 185, 187, 189, 192, 193, 194, 199, 200, 449, 554, 555, 557, 688, 689))
(LG08_test_map <- map(LG08_test_seq))


LG08_try <- try_seq(LG08_test_map, 199)
LG08_try
LG08_test_map <- make_seq(LG08_try, 25)

LG08_try <- try_seq(LG08_test_map, 200)
LG08_try
LG08_test_map <- make_seq(LG08_try, 25)


LG08_try <- try_seq(LG08_test_map, 192)
LG08_try
LG08_test_map <- make_seq(LG08_try, 27)

LG08_try <- try_seq(LG08_test_map, 193)
LG08_try
LG08_test_map <- make_seq(LG08_try, 27)

LG08_try <- try_seq(LG08_test_map, 194)
LG08_try
LG08_test_map <- make_seq(LG08_try, 27)

LG08_try <- try_seq(LG08_test_map, 182)
LG08_try
LG08_test_map <- make_seq(LG08_try, 30)

LG08_try <- try_seq(LG08_test_map, 185)
LG08_try
LG08_test_map <- make_seq(LG08_try, 30)

LG08_try <- try_seq(LG08_test_map, 187)
LG08_try
LG08_test_map <- make_seq(LG08_try, 30)

LG08_try <- try_seq(LG08_test_map, 189)
LG08_try
LG08_test_map <- make_seq(LG08_try, 30)


LG08_try <- try_seq(LG08_test_map, 170)
LG08_try
LG08_test_map <- make_seq(LG08_try, 34)

LG08_try <- try_seq(LG08_test_map, 171)
LG08_try
LG08_test_map <- make_seq(LG08_try, 34)

LG08_try <- try_seq(LG08_test_map, 174)
LG08_try
LG08_test_map <- make_seq(LG08_try, 34)

LG08_try <- try_seq(LG08_test_map, 175)
LG08_try
LG08_test_map <- make_seq(LG08_try, 34)

LG08_try <- try_seq(LG08_test_map, 179)
LG08_try
LG08_test_map <- make_seq(LG08_try, 34)


LG08_try <- try_seq(LG08_test_map, 164)
LG08_try
LG08_test_map <- make_seq(LG08_try, 39)

LG08_try <- try_seq(LG08_test_map, 165)
LG08_try
LG08_test_map <- make_seq(LG08_try, 39)

LG08_try <- try_seq(LG08_test_map, 168)
LG08_try
LG08_test_map <- make_seq(LG08_try, 39)

LG08_try <- try_seq(LG08_test_map, 169)
LG08_try
LG08_test_map <- make_seq(LG08_try, 38)

rf_graph_table(LG08_test_map, inter = FALSE, main = "LG08", graph.LOD = FALSE)




LG08_try <- try_seq(LG08_test_map, 449)
LG08_try
LG08_test_map <- make_seq(LG08_try, 43)

LG08_try <- try_seq(LG08_test_map, 554)
LG08_try
LG08_test_map <- make_seq(LG08_try, 44)

LG08_try <- try_seq(LG08_test_map, 555)
LG08_try
LG08_test_map <- make_seq(LG08_try, 43)

LG08_try <- try_seq(LG08_test_map, 557)
LG08_try
LG08_test_map <- make_seq(LG08_try, 43)

LG08_try <- try_seq(LG08_test_map, 688)
LG08_try
LG08_test_map <- make_seq(LG08_try, 47)

LG08_try <- try_seq(LG08_test_map, 689)
LG08_try
LG08_test_map <- make_seq(LG08_try, 48)
LG08_test_map
# now -529.6033


# markers at other end need to be reordered
LG08_test_seq <- drop_marker(LG08_test_map, c(162, 519, 628, 788, 858, 859, 860, 861, 862, 863, 946, 947, 948, 949, 950, 952))
(LG08_test_map <- map(LG08_test_seq))

LG08_try <- try_seq(LG08_test_map, 162)
LG08_try
LG08_test_map <- make_seq(LG08_try, 1)



LG08_try <- try_seq(LG08_test_map, 628)
LG08_try
LG08_test_map <- make_seq(LG08_try, 2)

LG08_try <- try_seq(LG08_test_map, 788)
LG08_try
LG08_test_map <- make_seq(LG08_try, 1)

LG08_try <- try_seq(LG08_test_map, 858)
LG08_try
LG08_test_map <- make_seq(LG08_try, 4)

LG08_try <- try_seq(LG08_test_map, 859)
LG08_try
LG08_test_map <- make_seq(LG08_try, 5)

LG08_try <- try_seq(LG08_test_map, 860)
LG08_try
LG08_test_map <- make_seq(LG08_try, 6)

LG08_try <- try_seq(LG08_test_map, 861)
LG08_try
LG08_test_map <- make_seq(LG08_try, 7)

LG08_try <- try_seq(LG08_test_map, 862)
LG08_try
LG08_test_map <- make_seq(LG08_try, 8)

LG08_try <- try_seq(LG08_test_map, 863)
LG08_try
LG08_test_map <- make_seq(LG08_try, 9)

LG08_try <- try_seq(LG08_test_map, 946)
LG08_try
LG08_test_map <- make_seq(LG08_try, 1)

LG08_try <- try_seq(LG08_test_map, 947)
LG08_try
LG08_test_map <- make_seq(LG08_try, 1)

LG08_try <- try_seq(LG08_test_map, 948)
LG08_try
LG08_test_map <- make_seq(LG08_try, 1)

LG08_try <- try_seq(LG08_test_map, 949)
LG08_try
LG08_test_map <- make_seq(LG08_try, 1)

LG08_try <- try_seq(LG08_test_map, 950)
LG08_try
LG08_test_map <- make_seq(LG08_try, 1)


LG08_try <- try_seq(LG08_test_map, 968)
LG08_try
LG08_test_map <- make_seq(LG08_try, 9)

LG08_try <- try_seq(LG08_test_map, 519)
LG08_try
LG08_test_map <- make_seq(LG08_try, 9)

LG08_try <- try_seq(LG08_test_map, 952)
LG08_try
LG08_test_map <- make_seq(LG08_try, 3)

rf_graph_table(LG08_test_map, inter = FALSE, main = "LG08", graph.LOD = FALSE)

# 968 is single marker bin with missind data. 
LG08_test_seq <- drop_marker(LG08_test_map, c(968))
(LG08_test_map <- map(LG08_test_seq))

#marker 628 has 35 markers from 11 contigs. This seems like it could be a repeat, or bad bin. 
# dropped it.
LG08_test_seq <- drop_marker(LG08_test_map, c(628))
(LG08_test_map <- map(LG08_test_seq))

#markers 950, 949, and 952 are out of order
LG08_test_seq <- drop_marker(LG08_test_map, c(949, 952, 950))
(LG08_test_map <- map(LG08_test_seq))

LG08_try <- try_seq(LG08_test_map, 949)
LG08_try
LG08_test_map <- make_seq(LG08_try, 1)

LG08_try <- try_seq(LG08_test_map, 950)
LG08_try
LG08_test_map <- make_seq(LG08_try, 1)

LG08_try <- try_seq(LG08_test_map, 952)
LG08_try
LG08_test_map <- make_seq(LG08_try, 1)
# Not best LOG, but I placed here because it is consistent with assembly

rf_graph_table(LG08_test_map, inter = FALSE, main = "LG08", graph.LOD = FALSE)


LG08_final <- LG08_test_map

#########################################################################
# Refine LG09                                                           #
#########################################################################

LG09_all


#remove redundant marker
LG09_test_seq <- drop_marker(LG09_all, c(412,415,416,211,216))
(LG09_test_map <- map(LG09_test_seq))
# log likelihood now -319.1963

rf_graph_table(LG09_test_map, inter = FALSE, main = "LG09", graph.LOD = FALSE)



# 212 single marker bin with missing data. 
# 213 , 910 single marker bin out of order with rest of contig.
LG09_test_seq <- drop_marker(LG09_test_map, c(212,213, 910))
(LG09_test_map <- map(LG09_test_seq))

rf_graph_table(LG09_test_map, inter = FALSE, main = "LG09", graph.LOD = FALSE)

# reorder end.
LG09_test_seq <- drop_marker(LG09_test_map, c(215,  210,  218,  217,  219,  220,  221,  222,  911,912))
(LG09_test_map <- map(LG09_test_seq))

# 218 single marker bin out of order with rest of contig.

LG09_try <- try_seq(LG09_test_map, 215)
LG09_try
LG09_test_map <- make_seq(LG09_try, 15)

LG09_try <- try_seq(LG09_test_map, 210)
LG09_try
LG09_test_map <- make_seq(LG09_try, 16)

LG09_try <- try_seq(LG09_test_map, 217)
LG09_try
LG09_test_map <- make_seq(LG09_try, 15)

LG09_try <- try_seq(LG09_test_map, 219)
LG09_try
LG09_test_map <- make_seq(LG09_try, 15)

LG09_try <- try_seq(LG09_test_map, 220)
LG09_try
LG09_test_map <- make_seq(LG09_try, 15)

LG09_try <- try_seq(LG09_test_map, 221)
LG09_try
LG09_test_map <- make_seq(LG09_try, 15)

LG09_try <- try_seq(LG09_test_map, 222)
LG09_try
LG09_test_map <- make_seq(LG09_try, 15)

LG09_try <- try_seq(LG09_test_map, 911)
LG09_try
LG09_test_map <- make_seq(LG09_try, 15)

LG09_try <- try_seq(LG09_test_map, 912)
LG09_try
LG09_test_map <- make_seq(LG09_try, 15)

#426 single marker bin with missind data
# 222 single marker bin out of order with rest of contig
LG09_test_seq <- drop_marker(LG09_test_map, c(426, 222))
(LG09_test_map <- map(LG09_test_seq))
rf_graph_table(LG09_test_map, inter = FALSE, main = "LG09", graph.LOD = FALSE)

# looks good
LG09_final <- LG09_test_map


#########################################################################
# Refine LG10                                                           #
#########################################################################

LG10_all


#remove redundant marker
LG10_test_seq <- drop_marker(LG10_all, c(274,276,279,630,631,633,636,771,773,775,777,924,926,882,881,879,876,675,678,680))
(LG10_test_map <- map(LG10_test_seq))
# log likelihood now -745.1942

rf_graph_table(LG10_test_map, inter = FALSE, main = "LG10", graph.LOD = FALSE)



# 264, 915, 776 single marker bin with missing data. 
# 260,958, 925, 901, 267, 640, 677 single marker bin out of order with rest of contig.
LG10_test_seq <- drop_marker(LG10_test_map, c(264, 915,260,958, 925, 901, 267,776,640,677))
(LG10_test_map <- map(LG10_test_seq))
rf_graph_table(LG10_test_map, inter = FALSE, main = "LG10", graph.LOD = FALSE)

# now reposition some markers at the end:
LG10_test_seq <- drop_marker(LG10_test_map, c(280, 281, 629, 632, 634, 635, 637, 638, 639, 676, 679, 681, 770, 772, 774, 778, 779, 780, 877, 878, 880, 883, 884, 922, 923, 927))
(LG10_test_map <- map(LG10_test_seq))


LG10_try <- try_seq(LG10_test_map, 280)
LG10_try
LG10_test_map <- make_seq(LG10_try, 27)
rf_graph_table(LG10_test_map, inter = FALSE, main = "LG10", graph.LOD = FALSE)

LG10_try <- try_seq(LG10_test_map, 281)
LG10_try
LG10_test_map <- make_seq(LG10_try, 27)

LG10_try <- try_seq(LG10_test_map, 629)
LG10_try
LG10_test_map <- make_seq(LG10_try, 29)

LG10_try <- try_seq(LG10_test_map, 632)
LG10_try
LG10_test_map <- make_seq(LG10_try, 30)

LG10_try <- try_seq(LG10_test_map, 634)
LG10_try
LG10_test_map <- make_seq(LG10_try, 31)

LG10_try <- try_seq(LG10_test_map, 635)
LG10_try
LG10_test_map <- make_seq(LG10_try, 32)

LG10_try <- try_seq(LG10_test_map, 637)
LG10_try
LG10_test_map <- make_seq(LG10_try, 33)

LG10_try <- try_seq(LG10_test_map, 638)
LG10_try
LG10_test_map <- make_seq(LG10_try, 34)

LG10_try <- try_seq(LG10_test_map, 676)
LG10_try
LG10_test_map <- make_seq(LG10_try, 35)

LG10_try <- try_seq(LG10_test_map, 679)
LG10_try
LG10_test_map <- make_seq(LG10_try, 36)

LG10_try <- try_seq(LG10_test_map, 681)
LG10_try
LG10_test_map <- make_seq(LG10_try, 37)

LG10_try <- try_seq(LG10_test_map, 770)
LG10_try
LG10_test_map <- make_seq(LG10_try, 35)

LG10_try <- try_seq(LG10_test_map, 772)
LG10_try
LG10_test_map <- make_seq(LG10_try, 36)

LG10_try <- try_seq(LG10_test_map, 774)
LG10_try
LG10_test_map <- make_seq(LG10_try, 37)

LG10_try <- try_seq(LG10_test_map, 778)
LG10_try
LG10_test_map <- make_seq(LG10_try, 38)

LG10_try <- try_seq(LG10_test_map, 779)
LG10_try
LG10_test_map <- make_seq(LG10_try, 39)

LG10_try <- try_seq(LG10_test_map, 780)
LG10_try
LG10_test_map <- make_seq(LG10_try, 40)

LG10_try <- try_seq(LG10_test_map, 877)
LG10_try
LG10_test_map <- make_seq(LG10_try, 41)

LG10_try <- try_seq(LG10_test_map, 878)
LG10_try
LG10_test_map <- make_seq(LG10_try, 41)

LG10_try <- try_seq(LG10_test_map, 880)
LG10_try
LG10_test_map <- make_seq(LG10_try, 41)

LG10_try <- try_seq(LG10_test_map, 883)
LG10_try
LG10_test_map <- make_seq(LG10_try, 41)

LG10_try <- try_seq(LG10_test_map, 884)
LG10_try
LG10_test_map <- make_seq(LG10_try, 48)

LG10_try <- try_seq(LG10_test_map, 923)
LG10_try
LG10_test_map <- make_seq(LG10_try, 41)

LG10_try <- try_seq(LG10_test_map, 927)
LG10_try
LG10_test_map <- make_seq(LG10_try, 42)

LG10_try <- try_seq(LG10_test_map, 639)
LG10_try
LG10_test_map <- make_seq(LG10_try, 35)

LG10_try <- try_seq(LG10_test_map, 922)
LG10_try
LG10_test_map <- make_seq(LG10_try, 41)

rf_graph_table(LG10_test_map, inter = FALSE, main = "LG10", graph.LOD = FALSE)

# drop 529, 271, 272, all single marker bin out of order with contig.
LG10_test_map
LG10_test_seq <- drop_marker(LG10_test_map, c(529, 272, 273))
(LG10_test_map <- map(LG10_test_seq))

rf_graph_table(LG10_test_map, inter = FALSE, main = "LG10", graph.LOD = FALSE)

# try repositioning 271
LG10_test_seq <- drop_marker(LG10_test_map, c(271))
(LG10_test_map <- map(LG10_test_seq))

LG10_try <- try_seq(LG10_test_map, 271)
LG10_try
LG10_test_map <- make_seq(LG10_try, 20)

rf_graph_table(LG10_test_map, inter = FALSE, main = "LG10", graph.LOD = FALSE)

# looks okay.
LG10_final <- LG10_test_map


#########################################################################
# Refine LG11                                                           #
#########################################################################

LG11_all


#remove redundant marker
LG11_test_seq <- drop_marker(LG11_all, c(537,532,530,336,338,341,343,345,348,350,352,353,355,358,359,361,364,870,872,874,646,645,642,784,786))
(LG11_test_map <- map(LG11_test_seq))
# log likelihood now -716.8967

rf_graph_table(LG11_test_map, inter = FALSE, main = "LG11", graph.LOD = FALSE)



# 513, 507 single marker bin with missing data. 
# 715, 342 534, 510, single marker bin out of order with rest of contig.
LG11_test_seq <- drop_marker(LG11_test_map, c(513, 507, 715, 342, 534, 510))
(LG11_test_map <- map(LG11_test_seq))
rf_graph_table(LG11_test_map, inter = FALSE, main = "LG11", graph.LOD = FALSE)

# reorder 721 through 713 and 966
LG11_test_seq <- drop_marker(LG11_test_map, c(713, 714, 716, 717, 718, 719, 720, 721, 966))
(LG11_test_map <- map(LG11_test_seq))

LG11_try <- try_seq(LG11_test_map, 713)
LG11_try
LG11_test_map <- make_seq(LG11_try, 1)

LG11_try <- try_seq(LG11_test_map, 714)
LG11_try
LG11_test_map <- make_seq(LG11_try, 2)

LG11_try <- try_seq(LG11_test_map, 718)
LG11_try
LG11_test_map <- make_seq(LG11_try, 3)

LG11_try <- try_seq(LG11_test_map, 719)
LG11_try
LG11_test_map <- make_seq(LG11_try, 4)

LG11_try <- try_seq(LG11_test_map, 720)
LG11_try
LG11_test_map <- make_seq(LG11_try, 5)

LG11_try <- try_seq(LG11_test_map, 721)
LG11_try
LG11_test_map <- make_seq(LG11_try, 6)

LG11_try <- try_seq(LG11_test_map, 966)
LG11_try
LG11_test_map <- make_seq(LG11_try, 1)
rf_graph_table(LG11_test_map, inter = FALSE, main = "LG11", graph.LOD = FALSE)

# the next two markers are single marker bins, but seem to be in order with contig.
LG11_try <- try_seq(LG11_test_map, 716)
LG11_try
LG11_test_map <- make_seq(LG11_try, 4)

LG11_try <- try_seq(LG11_test_map, 717)
LG11_try
LG11_test_map <- make_seq(LG11_try, 5)

# I don't like how the recombination plot looks with 716 and 717 in it. 
# dropped these two markers
LG11_test_seq <- drop_marker(LG11_test_map, c(716, 717))
(LG11_test_map <- map(LG11_test_seq))
rf_graph_table(LG11_test_map, inter = FALSE, main = "LG11", graph.LOD = FALSE)


# 339, 954, 873  single marker bin with nmissind data out of order
LG11_test_seq <- drop_marker(LG11_test_map, c(339, 954, 873))
(LG11_test_map <- map(LG11_test_seq))
rf_graph_table(LG11_test_map, inter = FALSE, main = "LG11", graph.LOD = FALSE)

# looks good
LG11_final <- LG11_test_map

#########################################################################
# Refine LG12                                                           #
#########################################################################

LG12_all


#remove redundant marker
LG12_test_seq <- drop_marker(LG12_all, c(653,651,649,377,380,906,686,684,670,668,666,662,661,657,655))
(LG12_test_map <- map(LG12_test_seq))
# log likelihood now -422.57

rf_graph_table(LG12_test_map, inter = FALSE, main = "LG12", graph.LOD = FALSE)

# marker 974 is single marker bin from a small contig represented only once. Dropped it. 
LG12_test_seq <- drop_marker(LG12_test_map, c(974))
(LG12_test_map <- map(LG12_test_seq))
rf_graph_table(LG12_test_map, inter = FALSE, main = "LG12", graph.LOD = FALSE)

# collection of markers is on wrong side.
LG12_test_seq <- drop_marker(LG12_test_map, c(648, 650, 652, 654, 967, 969))
(LG12_test_map <- map(LG12_test_seq))

LG12_try <- try_seq(LG12_test_map, 648)
LG12_try
LG12_test_map <- make_seq(LG12_try, 28)

LG12_try <- try_seq(LG12_test_map, 650)
LG12_try
LG12_test_map <- make_seq(LG12_try, 28)

LG12_try <- try_seq(LG12_test_map, 652)
LG12_try
LG12_test_map <- make_seq(LG12_try, 28)

LG12_try <- try_seq(LG12_test_map, 654)
LG12_try
LG12_test_map <- make_seq(LG12_try, 28)

LG12_try <- try_seq(LG12_test_map, 967)
LG12_try
LG12_test_map <- make_seq(LG12_try, 32)

LG12_try <- try_seq(LG12_test_map, 969)
LG12_try
LG12_test_map <- make_seq(LG12_try, 32)
rf_graph_table(LG12_test_map, inter = FALSE, main = "LG12", graph.LOD = FALSE)





# 381 single marker bin with missing data. 
# 376, 659 single marker bin out of order with rest of contig.
LG12_test_seq <- drop_marker(LG12_test_map, c(376, 381, 659))
(LG12_test_map <- map(LG12_test_seq))
rf_graph_table(LG12_test_map, inter = FALSE, main = "LG12", graph.LOD = FALSE)

# looks good
LG12_final <- LG12_test_map




#########################################################################
# Refine LG13                                                           #
#########################################################################

LG13_all


#remove redundant marker
LG13_test_seq <- drop_marker(LG13_all, c(836,834,916))
(LG13_test_map <- map(LG13_test_seq))
# log likelihood now -660.5764

rf_graph_table(LG13_test_map, inter = FALSE, main = "LG13", graph.LOD = FALSE)


# marker 830 is single marker bin
LG13_test_seq <- drop_marker(LG13_test_map, c(830))
(LG13_test_map <- map(LG13_test_seq))
rf_graph_table(LG13_test_map, inter = FALSE, main = "LG13", graph.LOD = FALSE)

# collection of markers is on wrong side.
LG13_test_seq <- drop_marker(LG13_test_map, c(831, 829, 828))
(LG13_test_map <- map(LG13_test_seq))

LG13_try <- try_seq(LG13_test_map, 831)
LG13_try
LG13_test_map <- make_seq(LG13_try, 47)

LG13_try <- try_seq(LG13_test_map, 829)
LG13_try
LG13_test_map <- make_seq(LG13_try, 48)

LG13_try <- try_seq(LG13_test_map, 828)
LG13_try
LG13_test_map <- make_seq(LG13_try, 49)

rf_graph_table(LG13_test_map, inter = FALSE, main = "LG13", graph.LOD = FALSE)


# 515 single marker bin with missing data. 
# 516, 517, 521 908, 835, 955 single marker bin out of order with rest of contig.
LG13_test_seq <- drop_marker(LG13_test_map, c(515, 516, 517, 521, 908, 835, 955))
(LG13_test_map <- map(LG13_test_seq))
rf_graph_table(LG13_test_map, inter = FALSE, main = "LG13", graph.LOD = FALSE)

# now need to break in half because one end needs to go on the other end. 

LG13_test_seq <- drop_marker(LG13_test_map, c(514, 518, 520, 522, 523, 524, 690, 790, 797, 827, 833, 837, 838))
(LG13_test_map <- map(LG13_test_seq))

LG13_try <- try_seq(LG13_test_map, 514)
LG13_try
LG13_test_map <- make_seq(LG13_try, 30)

LG13_try <- try_seq(LG13_test_map, 518)
LG13_try
LG13_test_map <- make_seq(LG13_try, 30)

LG13_try <- try_seq(LG13_test_map, 520)
LG13_try
LG13_test_map <- make_seq(LG13_try, 30)

LG13_try <- try_seq(LG13_test_map, 522)
LG13_try
LG13_test_map <- make_seq(LG13_try, 30)

LG13_try <- try_seq(LG13_test_map, 523)
LG13_try
LG13_test_map <- make_seq(LG13_try, 30)

LG13_try <- try_seq(LG13_test_map, 524)
LG13_try
LG13_test_map <- make_seq(LG13_try, 30)

LG13_try <- try_seq(LG13_test_map, 690)
LG13_try
LG13_test_map <- make_seq(LG13_try, 36)

LG13_try <- try_seq(LG13_test_map, 797)
LG13_try
LG13_test_map <- make_seq(LG13_try, 36)

LG13_try <- try_seq(LG13_test_map, 827)
LG13_try
LG13_test_map <- make_seq(LG13_try, 30)

LG13_try <- try_seq(LG13_test_map, 833)
LG13_try
LG13_test_map <- make_seq(LG13_try, 38)

LG13_try <- try_seq(LG13_test_map, 837)
LG13_try
LG13_test_map <- make_seq(LG13_try, 38)

LG13_try <- try_seq(LG13_test_map, 838)
LG13_try
LG13_test_map <- make_seq(LG13_try, 38)

LG13_try <- try_seq(LG13_test_map, 790)
LG13_try
LG13_test_map <- make_seq(LG13_try, 41)
rf_graph_table(LG13_test_map, inter = FALSE, main = "LG13", graph.LOD = FALSE)

LG13_test_map

# 972 is single marker bin from a contig present only once in the map. I will drop it. 
LG13_test_seq <- drop_marker(LG13_test_map, c(972))
(LG13_test_map <- map(LG13_test_seq))

# reorder a few markers in the middle. 
LG13_test_seq <- drop_marker(LG13_test_map, c(831,832,616))
(LG13_test_map <- map(LG13_test_seq))


LG13_try <- try_seq(LG13_test_map, 616)
LG13_try
LG13_test_map <- make_seq(LG13_try, 24)

LG13_try <- try_seq(LG13_test_map, 831)
LG13_try
LG13_test_map <- make_seq(LG13_try, 25)

LG13_try <- try_seq(LG13_test_map, 832)
LG13_try
LG13_test_map <- make_seq(LG13_try, 25)
rf_graph_table(LG13_test_map, inter = FALSE, main = "LG13", graph.LOD = FALSE)

LG13_test_map 


# looks good
LG13_final <- LG13_test_map


#########################################################################
# Refine LG14                                                           #
#########################################################################

LG14_all


#remove redundant marker
LG14_test_seq <- drop_marker(LG14_all, c(729,732,735,736,738,741,743,744,598,600,602))
(LG14_test_map <- map(LG14_test_seq))
# log likelihood now -230.3757

rf_graph_table(LG14_test_map, inter = FALSE, main = "LG14", graph.LOD = FALSE)


# marker 734, 746 is single marker bin out of order with rest of the contig.
LG14_test_seq <- drop_marker(LG14_test_map, c(734, 746))
(LG14_test_map <- map(LG14_test_seq))
rf_graph_table(LG14_test_map, inter = FALSE, main = "LG14", graph.LOD = FALSE)

# looks good
LG14_final <- LG14_test_map



#########################################################################
# Refine LG15                                                           #
#########################################################################

LG15_all


#remove redundant marker
LG15_test_seq <- drop_marker(LG15_all, c(622,626,887,888,890,892,822,819,818,815,814,811,898,856,854,850,848))
(LG15_test_map <- map(LG15_test_seq))
# log likelihood now -576.9642

rf_graph_table(LG15_test_map, inter = FALSE, main = "LG15", graph.LOD = FALSE)


# marker 849, 826 is single marker bin out of order with rest of the contig.
# drop 624 855, 896 - single marker bin with one missing datapoint. 
LG15_test_seq <- drop_marker(LG15_test_map, c(849, 855, 826, 896, 624))
(LG15_test_map <- map(LG15_test_seq))
rf_graph_table(LG15_test_map, inter = FALSE, main = "LG15", graph.LOD = FALSE)


# looks good
LG15_final <- LG15_test_map


########################################################################d
# Write maps to a file then order by genetic length                    #
########################################################################


female_final_maps_not_in_order <- list(LG01_final, LG02_final, LG03_final, LG04_final, LG05_final, LG06_final, LG07_final, LG08_final, LG09_final, LG10_final, LG11_final, LG12_final, LG13_final, LG14_final, LG15_final)

female_final_maps_not_in_order
write_map(map.list = final_maps_not_in_order, file.out = "female_final_maps_not_in_order.txt")


#Length of each linkage group, longest to shortest
# LG07 = 148.59 cM
# LG11 = 134.38 cM
# LG06 = 127.09 cM
# LG08 = 126.77 cM
# LG10 = 125.89 cM
# LG13 = 122.56 cM
# LG03 = 109.67 cM
# LG15 = 108.51 cM
# LG05 = 107.27 cM
# LG02 = 100.98 cM
# LG01 = 97.24 cM
# LG04 = 88.28 cM
# LG12 = 58.98 cM
# LG09 = 51.43 cM
# LG14 = 42.75 cM



# renamed linkage groups, longest to shortest.
sLG01 <- LG07_final
sLG02 <- LG11_final
sLG03 <- LG06_final
sLG04 <- LG08_final
sLG05 <- LG10_final
sLG06 <- LG13_final
sLG07 <- LG03_final
sLG08 <- LG15_final
sLG09 <- LG05_final
sLG10 <- LG02_final
sLG11 <- LG01_final
sLG12 <- LG04_final
sLG13 <- LG12_final
sLG14 <- LG09_final
sLG15 <- LG14_final



syntenic_linkage_groups <- list(sLG01, sLG02, sLG03, sLG04, sLG05, sLG06, sLG07, sLG08, sLG09, sLG10, sLG11, sLG12, sLG13, sLG14, sLG15)
write_map(map.list = syntenic_linkage_groups, file.out = "female_syntenic_linkage_groups.v1.txt")





########################################################################
# Look for how contigs are represented in linkage groups               #
########################################################################

#For information on this, see Matt's experiment HY529 and the excel spreadsheet with contig stats therein.
# briefly, the map written above is processed by "unbin_markers_in_map.pl" and then stats calculated by "calculate_unbinned_map_statistics.pl"
# this gives a tab delimited matrix of each contig and the number of markers it has in each linkage group.
# from this I was able to ID a few markers that should be removed from the unbinned map and also renamed in the final maps.


#Several markers will need to be renamed because bins were named after markers that don't belong in them
# Specifically:
# Rename marker	HyS0014.1081505	to	HyS0033.12083
# Rename marker	HyS0005.7105088	to	HyS0113.239440
# Rename marker	HyS0021.3990482	to	HyS0030.138614
# Rename marker	HyS0044.413181	to	HyS0055.1598783
# Rename marker	HyS0002.7084340	to	HyS0065.343652
# Rename marker	HyS0008.595396	to	HyS0024.370355





########################################################################
# Drawing maps                                                         #
########################################################################

#For figure in main text.
draw_map2(syntenic_linkage_groups, output = "female_syntenic_linkage_groups.v1.eps", group.names = c("LG1", "LG2","LG3","LG4", "LG5", "LG6", "LG7", "LG8", "LG9", "LG10", "LG11", "LG12", "LG13", "LG14", "LG15"), space = 0.5)

#For the supplemental figure with the marker names:
draw_map2(syntenic_linkage_groups, output = "female_syntenic_linkage_groups.v1.detailed.eps", group.names = c("1", "2","3","4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15"), space = 3.5, tag= "all" )

