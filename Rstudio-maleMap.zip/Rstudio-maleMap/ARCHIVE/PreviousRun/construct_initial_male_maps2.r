#########################################################################
# Build Initial Maps                                                    #
#########################################################################

# start onemap
library(onemap)

# read in data
rawdata <- read_onemap(inputfile = "malePT.5kb.raw")

# find bins, test segregation, do two point tests, and construct linkage groups
bins <- find_bins(rawdata, exact = FALSE)
binned_data <- create_data_bins(rawdata, bins = bins)
segreg_test <- test_segregation(binned_data)
no_dist <- select_segreg(segreg_test, distorted = FALSE, numbers = TRUE)
LOD_sug <- suggest_lod(binned_data)
twopts <- rf_2pts(binned_data, LOD = LOD_sug, max.rf = 0.4)
mark_no_dist <- make_seq(twopts, c(no_dist))
LGs <- group(mark_no_dist)

#Only get 15 linkage groups

# do initial ordering of markers.
set_map_fun("kosambi")
LG01 <- make_seq(LGs, 1)
LG02 <- make_seq(LGs, 2)
LG03 <- make_seq(LGs, 3)
LG04 <- make_seq(LGs, 4)
LG05 <- make_seq(LGs, 5)
LG06 <- make_seq(LGs, 6)
LG07 <- make_seq(LGs, 7)
LG08 <- make_seq(LGs, 8)
LG09 <- make_seq(LGs, 9)
LG10 <- make_seq(LGs, 10)
LG11 <- make_seq(LGs, 11)
LG12 <- make_seq(LGs, 12)
LG13 <- make_seq(LGs, 13)
LG14 <- make_seq(LGs, 14)
LG15 <- make_seq(LGs, 15)
LG01_ord <- order_seq(LG01, n.init = 5, THRES = 3)
LG02_ord <- order_seq(LG02, n.init = 5, THRES = 3)
LG03_ord <- order_seq(LG03, n.init = 5, THRES = 3)
LG04_ord <- order_seq(LG04, n.init = 5, THRES = 3)
LG05_ord <- order_seq(LG05, n.init = 5, THRES = 3)
LG06_ord <- order_seq(LG06, n.init = 5, THRES = 3)
LG07_ord <- order_seq(LG07, n.init = 5, THRES = 3)
LG08_ord <- order_seq(LG08, n.init = 5, THRES = 3)
LG09_ord <- order_seq(LG09, n.init = 5, THRES = 3)
LG10_ord <- order_seq(LG10, n.init = 5, THRES = 3)
LG11_ord <- order_seq(LG11, n.init = 5, THRES = 3)
LG12_ord <- order_seq(LG12, n.init = 5, THRES = 3)
LG13_ord <- order_seq(LG13, n.init = 5, THRES = 3)
LG14_ord <- order_seq(LG14, n.init = 5, THRES = 3)
LG15_ord <- order_seq(LG15, n.init = 5, THRES = 3)
LG01_all <- make_seq(LG01_ord, "force")
LG02_all <- make_seq(LG02_ord, "force")
LG03_all <- make_seq(LG03_ord, "force")
LG04_all <- make_seq(LG04_ord, "force")
LG05_all <- make_seq(LG05_ord, "force")
LG06_all <- make_seq(LG06_ord, "force")
LG07_all <- make_seq(LG07_ord, "force")
LG08_all <- make_seq(LG08_ord, "force")
LG09_all <- make_seq(LG09_ord, "force")
LG10_all <- make_seq(LG10_ord, "force")
LG11_all <- make_seq(LG11_ord, "force")
LG12_all <- make_seq(LG12_ord, "force")
LG13_all <- make_seq(LG13_ord, "force")
LG14_all <- make_seq(LG14_ord, "force")
LG15_all <- make_seq(LG15_ord, "force")


###############################################
# Create files for removing redunant markers
###############################################
library(onemap)

initial_maps <- list(LG01_all, LG02_all, LG03_all, LG04_all, LG05_all, LG06_all, LG07_all, LG08_all, LG09_all, LG10_all, LG11_all, LG12_all, LG13_all, LG14_all, LG15_all)
sink(file = "firstmalemaps.txt")
initial_maps
closeAllConnections()

# also run the script "save_bins" without loading oneMap.

# then run perl script identify_redundant_markers.pl


#########################################################################
# Refine LG01                                                           #
#########################################################################

LG01_all

rf_graph_table(LG01_all, inter = FALSE, main = "LG01 - initial map")

#remove redundant markers
LG01_test_seq <- drop_marker(LG01_all, c(285,283,282,279,237,236,234,231,230,227,222,5,7,10,11,14,377))
(LG01_test_map <- map(LG01_test_seq))
# log likelihood now still -435.33


rf_graph_table(LG01_test_map, inter = FALSE, main = "LG01 - initial map")

#some markers look out of place. 
LG01_test_seq <- drop_marker(LG01_test_seq, c(379, 8, 380, 356, 3))
(LG01_test_map <- map(LG01_test_seq))
rf_graph_table(LG01_test_map, inter = FALSE, main = "LG01 - initial map")
#likelihood now -327.02

# marker 8 is single marker bin with 6 missing datapoints. Will remove it permanently
# marker 3 is single marker bin from contig 1, which has many other multimarker bins. Removed permanently


LG01_try <- try_seq(LG01_test_map, 380)
LG01_try
# this shows marker 380 getting put back where it was. I wonder whether 378 is also in wrong place. 

LG01_test_seq <- drop_marker(LG01_test_seq, c(378, 351, 352, 353, 354))
(LG01_test_map <- map(LG01_test_seq))
rf_graph_table(LG01_test_map, inter = FALSE, main = "LG01 - initial map")

# add them back in sequentially
LG01_try <- try_seq(LG01_test_map, 351)
LG01_try
LG01_test_map <- make_seq(LG01_try, 28)
rf_graph_table(LG01_test_map, inter = FALSE, main = "LG01 - initial map")

LG01_try <- try_seq(LG01_test_map, 352)
LG01_try
LG01_test_map <- make_seq(LG01_try, 28)
rf_graph_table(LG01_test_map, inter = FALSE, main = "LG01 - initial map")

LG01_try <- try_seq(LG01_test_map, 353)
LG01_try
LG01_test_map <- make_seq(LG01_try, 27)
rf_graph_table(LG01_test_map, inter = FALSE, main = "LG01 - initial map")

LG01_try <- try_seq(LG01_test_map, 354)
LG01_try
LG01_test_map <- make_seq(LG01_try, 27)
rf_graph_table(LG01_test_map, inter = FALSE, main = "LG01 - initial map")

LG01_try <- try_seq(LG01_test_map, 378)
LG01_try
LG01_test_map <- make_seq(LG01_try, 27)
rf_graph_table(LG01_test_map, inter = FALSE, main = "LG01 - initial map")


# I think 380 could be double recomginant. IT's a single marker bin from a contig that has lots of multimarker bins, e.g. 13, 12. I will not put it back


# looks okay
LG01_final <- LG01_test_map



#########################################################################
# Refine LG02                                                           #
#########################################################################

LG02_all

#remove redundant markers
LG02_test_seq <- drop_marker(LG02_all, c(438,403,401,16,17,19,22,23,25,278,274,263,261))
(LG02_test_map <- map(LG02_test_seq))
# log likelihood now -531.82

rf_graph_table(LG02_test_map, inter = FALSE, main = "LG02")

# ew. Many markers at one end are messed up. 
# 33, 217 and 218 are single marker bins with lots of missing data, and are also in the ARC. Likely to be problematic. Remove permanently.
LG02_test_seq <- drop_marker(LG02_test_map, c(218, 217, 33))
(LG02_test_map <- map(LG02_test_seq))
rf_graph_table(LG02_test_map, inter = FALSE, main = "LG02", graph.LOD = TRUE)

# 32 is single marker bin and out of place with our current map of the ARC. Will remove. 
LG02_test_seq <- drop_marker(LG02_test_map, c(32))
(LG02_test_map <- map(LG02_test_seq))
rf_graph_table(LG02_test_map, inter = FALSE, main = "LG02", graph.LOD = TRUE)

# same story for 276
LG02_test_seq <- drop_marker(LG02_test_map, c(276))
(LG02_test_map <- map(LG02_test_seq))
rf_graph_table(LG02_test_map, inter = FALSE, main = "LG02", graph.LOD = TRUE)

# 216 is single marker bin and it's placement is at odds with our current ARC map. Will remove.
LG02_test_seq <- drop_marker(LG02_test_map, c(216))
(LG02_test_map <- map(LG02_test_seq))
rf_graph_table(LG02_test_map, inter = FALSE, main = "LG02", graph.LOD = TRUE)


# try re-placing 267
LG02_test_seq <- drop_marker(LG02_test_map, c(267))
(LG02_test_map <- map(LG02_test_seq))
LG02_try <- try_seq(LG02_test_map, 267)
LG02_try
LG02_test_map <- make_seq(LG02_try, 24)

rf_graph_table(LG02_test_map, inter = FALSE, main = "LG02", graph.LOD = TRUE)
LG02_test_map

# looks ok now.

LG02_final <- LG02_test_map





#########################################################################
# Refine LG03                                                           #
#########################################################################

LG03_all
#remove redundant markers
LG03_test_seq <- drop_marker(LG03_all, c(384,386,389,390,140,142,145,149,150,39,42,45))
(LG03_test_map <- map(LG03_test_seq))
# log likelihood now -312.9242

rf_graph_table(LG03_test_map, inter = FALSE, main = "LG03")

# maybe tweak a few markers
LG03_test_seq <- drop_marker(LG03_test_map, c(151))
(LG03_test_map <- map(LG03_test_seq))
LG03_try <- try_seq(LG03_test_map, 151)
LG03_try
LG03_test_map <- make_seq(LG03_try, 12)
#same spot

#35 and 37 are 3 marker and single marker bins with lots of missing data, respectively. Will remove them.  
LG03_test_seq <- drop_marker(LG03_test_map, c(35, 37))
(LG03_test_map <- map(LG03_test_seq))
rf_graph_table(LG03_test_map, inter = FALSE, main = "LG03")

# try to reposition 34
LG03_test_seq <- drop_marker(LG03_test_map, c(34))
(LG03_test_map <- map(LG03_test_seq))
LG03_try <- try_seq(LG03_test_map, 34)
LG03_try
LG03_test_map <- make_seq(LG03_try, 14)
rf_graph_table(LG03_test_map, inter = FALSE, main = "LG03")
# better position.

LG03_test_seq <- drop_marker(LG03_test_map, c(476))
(LG03_test_map <- map(LG03_test_seq))
LG03_try <- try_seq(LG03_test_map, 476)
LG03_try
LG03_test_map <- make_seq(LG03_try, 20)
rf_graph_table(LG03_test_map, inter = FALSE, main = "LG03")
LG03_test_map
# other than it being a single marker bin froma small contig, there's no reason to exclude. I will keep that marker in.

#looks good

LG03_final <- LG03_test_map

#########################################################################
# Refine LG04                                                           #
#########################################################################

LG04_all

#remove redundant markers
LG04_test_seq <- drop_marker(LG04_all, c(61,221,154,152))
(LG04_test_map <- map(LG04_test_seq))
# log likelihood now still -499.4405

rf_graph_table(LG04_test_map, inter = FALSE, main = "LG04")

#481 and 58 stick out as problematic right off. 58 IS SINGLE MARKER, with missing data. 481 is just single marker, no missing data.
# remove 58
LG04_test_seq <- drop_marker(LG04_test_map, c(58))
(LG04_test_map <- map(LG04_test_seq))
rf_graph_table(LG04_test_map, inter = FALSE, main = "LG04")

# makers from 220 through 290 mibht be better positioned relative to each other.
LG04_test_seq <- drop_marker(LG04_test_map, c(220, 219, 155, 463, 153, 292, 291, 290))
(LG04_test_map <- map(LG04_test_seq))

LG04_try <- try_seq(LG04_test_map, 153)
LG04_try
LG04_test_map <- make_seq(LG04_try, 17)

LG04_try <- try_seq(LG04_test_map, 155)
LG04_try
LG04_test_map <- make_seq(LG04_try, 17)

LG04_try <- try_seq(LG04_test_map, 219)
LG04_try
LG04_test_map <- make_seq(LG04_try, 17)

LG04_try <- try_seq(LG04_test_map, 220)
LG04_try
LG04_test_map <- make_seq(LG04_try, 17)

LG04_try <- try_seq(LG04_test_map, 290)
LG04_try
LG04_test_map <- make_seq(LG04_try, 21)

LG04_try <- try_seq(LG04_test_map, 291)
LG04_try
LG04_test_map <- make_seq(LG04_try, 21)

LG04_try <- try_seq(LG04_test_map, 292)
LG04_try
LG04_test_map <- make_seq(LG04_try, 21)

LG04_try <- try_seq(LG04_test_map, 463)
LG04_try
LG04_test_map <- make_seq(LG04_try, 20)
# no change.

# marker 463 is from contig 94, which is also included in marker 153.

# try repositioning 481
LG04_test_seq <- drop_marker(LG04_test_map, c(481))
(LG04_test_map <- map(LG04_test_seq))

LG04_try <- try_seq(LG04_test_map, 481)
LG04_try
LG04_test_map <- make_seq(LG04_try, 1)


rf_graph_table(LG04_test_map, inter = FALSE, main = "LG04")
LG04_test_map

# as good as it's going to get.

LG04_final <- LG04_test_map

#########################################################################
# Refine LG05                                                           #
#########################################################################

LG05_all

#remove redundant markers
LG05_test_seq <- drop_marker(LG05_all, c(195,197,193,190,187,185,64,67))
(LG05_test_map <- map(LG05_test_seq))
# log likelihood now still -419.3443

rf_graph_table(LG05_test_map, inter = FALSE, main = "LG05")

#marker 70 is single marker with 7 missing datapoints.
LG05_test_seq <- drop_marker(LG05_test_map, c(70))
(LG05_test_map <- map(LG05_test_seq))
# log likelihood now still -387.1182


rf_graph_table(LG05_test_map, inter = FALSE, main = "LG05")

#marker 457 is single marker bin, from contig 86. Rest of contig 86 is in marker 71. I will drop and readd both.
LG05_test_seq <- drop_marker(LG05_test_map, c(71, 457))
(LG05_test_map <- map(LG05_test_seq))

LG05_try <- try_seq(LG05_test_map, 71)
LG05_try
LG05_test_map <- make_seq(LG05_try, 15)

LG05_try <- try_seq(LG05_test_map, 457)
LG05_try
LG05_test_map <- make_seq(LG05_try, 16)


rf_graph_table(LG05_test_map, inter = FALSE, main = "LG05")

# marker 191 looks out of place. Will drop and readd
LG05_test_seq <- drop_marker(LG05_test_map, c(191))
(LG05_test_map <- map(LG05_test_seq))
LG05_try <- try_seq(LG05_test_map, 191)
LG05_try
LG05_test_map <- make_seq(LG05_try, 7)
# put it back in same place. Could be double.
# It's in the middle of a well represented contig. I will remove it. 
LG05_test_seq <- drop_marker(LG05_test_map, c(191))
(LG05_test_map <- map(LG05_test_seq))
# log likelihood = -371.8527

rf_graph_table(LG05_test_map, inter = FALSE, main = "LG05")





# I think it's as good as it can get. 


LG05_final <- LG05_test_map



#########################################################################
# Refine LG06                                                           #
#########################################################################

LG06_all

#remove redundant markers
LG06_test_seq <- drop_marker(LG06_all, c(271,74,78,80,82,87,90,91,94))
(LG06_test_map <- map(LG06_test_seq))
# log likelihood now still -399.981

rf_graph_table(LG06_test_map, inter = FALSE, main = "LG06")

#marker 76, 79 are in bad spots.
LG06_test_seq <- drop_marker(LG06_test_map, c(76,79))
(LG06_test_map <- map(LG06_test_seq))
LG06_try <- try_seq(LG06_test_map, 76)
LG06_try
LG06_test_map <- make_seq(LG06_try, 14)

LG06_try <- try_seq(LG06_test_map, 79)
LG06_try
LG06_test_map <- make_seq(LG06_try, 14)
rf_graph_table(LG06_test_map, inter = FALSE, main = "LG06")

# this is not much better. Both are single marker bins with missing data. Removed them. 
LG06_test_seq <- drop_marker(LG06_test_map, c(76,79))
(LG06_test_map <- map(LG06_test_seq))
# log likelihood now still -298.6009
rf_graph_table(LG06_test_map, inter = FALSE, main = "LG06")


#markers 75, 73 might bs swapped.
LG06_test_seq <- drop_marker(LG06_test_map, c(75,73))
(LG06_test_map <- map(LG06_test_seq))
LG06_try <- try_seq(LG06_test_map, 75)
LG06_try
LG06_test_map <- make_seq(LG06_try, 12)

LG06_try <- try_seq(LG06_test_map, 73)
LG06_try
LG06_test_map <- make_seq(LG06_try, 13)
rf_graph_table(LG06_test_map, inter = FALSE, main = "LG06")
# puts them in same spot. 

# 75 is a single marker bin, and from the middle of a contig that is wel represented by multimarker bins. Will remove.
LG06_test_seq <- drop_marker(LG06_test_map, c(75))
(LG06_test_map <- map(LG06_test_seq))
rf_graph_table(LG06_test_map, inter = FALSE, main = "LG06")


#81 through 92 might have a better order. 
LG06_test_seq <- drop_marker(LG06_test_map, c(81, 83, 84, 85, 86, 88, 89, 92))
(LG06_test_map <- map(LG06_test_seq))


LG06_try <- try_seq(LG06_test_map, 81)
LG06_try
LG06_test_map <- make_seq(LG06_try, 14)

LG06_try <- try_seq(LG06_test_map, 83)
LG06_try
LG06_test_map <- make_seq(LG06_try, 15)

LG06_try <- try_seq(LG06_test_map, 84)
LG06_try
LG06_test_map <- make_seq(LG06_try, 16)

LG06_try <- try_seq(LG06_test_map, 85)
LG06_try
LG06_test_map <- make_seq(LG06_try, 17)

LG06_try <- try_seq(LG06_test_map, 86)
LG06_try
LG06_test_map <- make_seq(LG06_try, 18)

LG06_try <- try_seq(LG06_test_map, 88)
LG06_try
LG06_test_map <- make_seq(LG06_try, 19)

LG06_try <- try_seq(LG06_test_map, 89)
LG06_try
LG06_test_map <- make_seq(LG06_try, 20)

LG06_try <- try_seq(LG06_test_map, 92)
LG06_try
LG06_test_map <- make_seq(LG06_try, 21)


rf_graph_table(LG06_test_map, inter = FALSE, main = "LG06")

LG06_test_map
# log = -290.6569


# I think it's as good as it can get. 


LG06_final <- LG06_test_map


#########################################################################
# Refine LG07                                                           #
#########################################################################

LG07_all

#remove redundant markers
LG07_test_seq <- drop_marker(LG07_all, c(98,101,104,106,107,202))
(LG07_test_map <- map(LG07_test_seq))
# log likelihood now still -264.7171

rf_graph_table(LG07_test_map, inter = FALSE, main = "LG07")

#marker marker 111 is single marker, probably double recombinant.
LG07_test_seq <- drop_marker(LG07_test_map, c(111))
(LG07_test_map <- map(LG07_test_seq))

# looks good.

LG07_final <- LG07_test_map



#########################################################################
# Refine LG08                                                           #
#########################################################################

LG08_all

#remove redundant markers
LG08_test_seq <- drop_marker(LG08_all, c(423,421,418,397))
(LG08_test_map <- map(LG08_test_seq))
# log likelihood now still -244.6206

rf_graph_table(LG08_test_map, inter = FALSE, main = "LG08")

# big jump from marker 419 to 420, but nothing bad about underlying data.

LG08_final <- LG08_test_map 


#########################################################################
# Refine LG09                                                           #
#########################################################################

LG09_all

#remove redundant markers
LG09_test_seq <- drop_marker(LG09_all, c(168,167,164,162,161))
(LG09_test_map <- map(LG09_test_seq))
# log likelihood now still -216.8302

rf_graph_table(LG09_test_map, inter = FALSE, main = "LG09")

# Marker 121 looks out of place.21 is single marker bin with no missing data. Marker 120 is single marker bin with three missing datapoints.
# will try to drop and readd both.
LG09_test_seq <- drop_marker(LG09_test_map, c(120, 121))
(LG09_test_map <- map(LG09_test_seq))
LG09_try <- try_seq(LG09_test_map, 121)
LG09_try
LG09_test_map <- make_seq(LG09_try, 1)

LG09_try <- try_seq(LG09_test_map, 120)
LG09_try
# this placement doesn't make sense. I will not readd 120.

rf_graph_table(LG09_test_map, inter = FALSE, main = "LG09")

LG09_final <- LG09_test_map 

#########################################################################
# Refine LG10                                                           #
#########################################################################

LG10_all

#remove redundant markers
LG10_test_seq <- drop_marker(LG10_all, c(464,447,446,461,459,332))
(LG10_test_map <- map(LG10_test_seq))
# log likelihood now still -403.3496

rf_graph_table(LG10_test_map, inter = FALSE, main = "LG10")

# marker 137 is a single bin marker with 9 missing datapoints. Dropped it.
LG10_test_seq <- drop_marker(LG10_test_map, c(137))
(LG10_test_map <- map(LG10_test_seq))
rf_graph_table(LG10_test_map, inter = FALSE, main = "LG10")

#markers 133 through 488 seem out of order
# 133 is single marker with 5 missing datapoints. will drop permanently.
# 383 is single marker bin. will add at end. 
# 454 is single marker bin. will add at end.
LG10_test_seq <- drop_marker(LG10_test_map, c(132, 133, 134, 135, 136, 138, 139, 381, 382, 383, 448, 454, 465))
(LG10_test_map <- map(LG10_test_seq))
rf_graph_table(LG10_test_map, inter = FALSE, main = "LG10")

LG10_try <- try_seq(LG10_test_map, 465)
LG10_try
LG10_test_map <- make_seq(LG10_try, 10)
rf_graph_table(LG10_test_map, inter = FALSE, main = "LG10")

LG10_try <- try_seq(LG10_test_map, 448)
LG10_try
LG10_test_map <- make_seq(LG10_try, 11)
rf_graph_table(LG10_test_map, inter = FALSE, main = "LG10")

LG10_try <- try_seq(LG10_test_map, 382)
LG10_try
LG10_test_map <- make_seq(LG10_try, 10)

LG10_try <- try_seq(LG10_test_map, 381)
LG10_try
LG10_test_map <- make_seq(LG10_try, 10)
rf_graph_table(LG10_test_map, inter = FALSE, main = "LG10")

LG10_try <- try_seq(LG10_test_map, 139)
LG10_try
LG10_test_map <- make_seq(LG10_try, 10)
rf_graph_table(LG10_test_map, inter = FALSE, main = "LG10")

LG10_try <- try_seq(LG10_test_map, 138)
LG10_try
LG10_test_map <- make_seq(LG10_try, 10)
rf_graph_table(LG10_test_map, inter = FALSE, main = "LG10")

LG10_try <- try_seq(LG10_test_map, 136)
LG10_try
LG10_test_map <- make_seq(LG10_try, 10)
rf_graph_table(LG10_test_map, inter = FALSE, main = "LG10")

LG10_try <- try_seq(LG10_test_map, 135)
LG10_try
LG10_test_map <- make_seq(LG10_try, 10)
rf_graph_table(LG10_test_map, inter = FALSE, main = "LG10")

LG10_try <- try_seq(LG10_test_map, 134)
LG10_try
LG10_test_map <- make_seq(LG10_try, 10)
rf_graph_table(LG10_test_map, inter = FALSE, main = "LG10")


LG10_try <- try_seq(LG10_test_map, 132)
LG10_try
LG10_test_map <- make_seq(LG10_try, 10)
rf_graph_table(LG10_test_map, inter = FALSE, main = "LG10")

LG10_test_map

LG10_try <- try_seq(LG10_test_map, 383)
LG10_try
# 383 gets put in a weird place. will try and see what it looks like.
LG10_test_map <- make_seq(LG10_try, 13)
rf_graph_table(LG10_test_map, inter = FALSE, main = "LG10")
# not a good placement. Will drop 383
LG10_test_seq <- drop_marker(LG10_test_map, c(383))
(LG10_test_map <- map(LG10_test_seq))
rf_graph_table(LG10_test_map, inter = FALSE, main = "LG10")

LG10_try <- try_seq(LG10_test_map, 454)
LG10_try
LG10_test_map <- make_seq(LG10_try, 10)

rf_graph_table(LG10_test_map, inter = FALSE, main = "LG10")


# now let's retest marker 253 and 254
LG10_test_seq <- drop_marker(LG10_test_map, c(253,254))
(LG10_test_map <- map(LG10_test_seq))
rf_graph_table(LG10_test_map, inter = FALSE, main = "LG10")

LG10_try <- try_seq(LG10_test_map, 253)
LG10_try
LG10_test_map <- make_seq(LG10_try, 2)
rf_graph_table(LG10_test_map, inter = FALSE, main = "LG10")

LG10_try <- try_seq(LG10_test_map, 254)
LG10_try
# still puts it in a weird place. Since it doesn't affect the contig placement at all, I will drop permanently. 

LG10_test_map
rf_graph_table(LG10_test_map, inter = FALSE, main = "LG10")


LG10_final <- LG10_test_map


#########################################################################
# Refine LG11                                                           #
#########################################################################

LG11_all

#remove redundant markers
LG11_test_seq <- drop_marker(LG11_all, c(258,173,311,309,392))
(LG11_test_map <- map(LG11_test_seq))
# log likelihood now still -216.8302
rf_graph_table(LG11_test_map, inter = FALSE, main = "LG11")


# 243, 245 and 256 are single marker bins with several missing genotypes. Dropped permanently.
LG11_test_seq <- drop_marker(LG11_test_map, c(243, 245, 256))
(LG11_test_map <- map(LG11_test_seq))
rf_graph_table(LG11_test_map, inter = FALSE, main = "LG11")


LG11_try <- try_seq(LG11_test_map, )
LG11_try
LG11_test_map <- make_seq(LG11_try, )


rf_graph_table(LG11_test_map, inter = FALSE, main = "LG11")

LG11_final <- LG11_test_map 













###############################################################################################################
###############################################################################################################
##
##
##   LEFT OFF HERE ON December 3
##
##
###############################################################################################################
###############################################################################################################










#########################################################################
# Refine LG06                                                           #
#########################################################################


#remove redundant markers
LG06_test_seq <- drop_marker(LG06_all, c())
(LG06_test_map <- map(LG06_test_seq))
# log likelihood now still -649.8895

rf_graph_table(LG06_test_map, inter = FALSE, main = "LG06")



LG06_final <- LG06_test_map
#########################################################################
# Refine LG06                                                           #
#########################################################################


#remove redundant markers
LG06_test_seq <- drop_marker(LG06_all, c())
(LG06_test_map <- map(LG06_test_seq))
# log likelihood now still -649.8895

rf_graph_table(LG06_test_map, inter = FALSE, main = "LG06")



LG06_final <- LG06_test_map
#########################################################################
# Refine LG06                                                           #
#########################################################################


#remove redundant markers
LG06_test_seq <- drop_marker(LG06_all, c())
(LG06_test_map <- map(LG06_test_seq))
# log likelihood now still -649.8895

rf_graph_table(LG06_test_map, inter = FALSE, main = "LG06")



LG06_final <- LG06_test_map
#########################################################################
# Refine LG06                                                           #
#########################################################################


#remove redundant markers
LG06_test_seq <- drop_marker(LG06_all, c())
(LG06_test_map <- map(LG06_test_seq))
# log likelihood now still -649.8895

rf_graph_table(LG06_test_map, inter = FALSE, main = "LG06")



LG06_final <- LG06_test_map
#########################################################################
# Refine LG06                                                           #
#########################################################################


#remove redundant markers
LG06_test_seq <- drop_marker(LG06_all, c())
(LG06_test_map <- map(LG06_test_seq))
# log likelihood now still -649.8895

rf_graph_table(LG06_test_map, inter = FALSE, main = "LG06")



LG06_final <- LG06_test_map
#########################################################################
# Refine LG06                                                           #
#########################################################################


#remove redundant markers
LG06_test_seq <- drop_marker(LG06_all, c())
(LG06_test_map <- map(LG06_test_seq))
# log likelihood now still -649.8895

rf_graph_table(LG06_test_map, inter = FALSE, main = "LG06")



LG06_final <- LG06_test_map
#########################################################################
# Refine LG06                                                           #
#########################################################################


#remove redundant markers
LG06_test_seq <- drop_marker(LG06_all, c())
(LG06_test_map <- map(LG06_test_seq))
# log likelihood now still -649.8895

rf_graph_table(LG06_test_map, inter = FALSE, main = "LG06")



LG06_final <- LG06_test_map
#########################################################################
# Refine LG06                                                           #
#########################################################################


#remove redundant markers
LG06_test_seq <- drop_marker(LG06_all, c())
(LG06_test_map <- map(LG06_test_seq))
# log likelihood now still -649.8895

rf_graph_table(LG06_test_map, inter = FALSE, main = "LG06")



LG06_final <- LG06_test_map
#########################################################################
# Refine LG06                                                           #
#########################################################################


#remove redundant markers
LG06_test_seq <- drop_marker(LG06_all, c())
(LG06_test_map <- map(LG06_test_seq))
# log likelihood now still -649.8895

rf_graph_table(LG06_test_map, inter = FALSE, main = "LG06")



LG06_final <- LG06_test_map
#########################################################################
# Refine LG06                                                           #
#########################################################################


#remove redundant markers
LG06_test_seq <- drop_marker(LG06_all, c())
(LG06_test_map <- map(LG06_test_seq))
# log likelihood now still -649.8895

rf_graph_table(LG06_test_map, inter = FALSE, main = "LG06")



LG06_final <- LG06_test_map
#########################################################################
# Refine LG06                                                           #
#########################################################################


#remove redundant markers
LG06_test_seq <- drop_marker(LG06_all, c())
(LG06_test_map <- map(LG06_test_seq))
# log likelihood now still -649.8895

rf_graph_table(LG06_test_map, inter = FALSE, main = "LG06")



LG06_final <- LG06_test_map



########################################################################
# Drawing maps                                                         #
########################################################################

draw_map2(syntenic_linkage_groups, output = "syntenic_linkage_groups.png", group.names = c("LG1", "LG2","LG3","LG4", "LG5", "LG6", "LG7", "LG8", "LG9", "LG10", "LG11", "LG12", "LG13", "LG14", "LG15"), space = "1")
draw_map2(syntenic_linkage_groups, output = "syntenic_linkage_groups.png", group.names = c("LG1", "LG2","LG3","LG4", "LG5", "LG6", "LG7", "LG8", "LG9", "LG10", "LG11", "LG12", "LG13", "LG14", "LG15"), space = 1)
draw_map2(syntenic_linkage_groups, output = "syntenic_linkage_groups.png", group.names = c("LG1", "LG2","LG3","LG4", "LG5", "LG6", "LG7", "LG8", "LG9", "LG10", "LG11", "LG12", "LG13", "LG14", "LG15"), tag = "all")



