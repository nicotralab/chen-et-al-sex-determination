options(max.print = 30000)
sink(file = "malebins.txt")
bins
closeAllConnections()
