#########################################################################
# Build Initial Maps                                                    #
#########################################################################

# start onemap
library(onemap)

# read in data
rawdata <- read_onemap(inputfile = "malePT.5kb.raw")

# find bins, test segregation, do two point tests, and construct linkage groups
bins <- find_bins(rawdata, exact = FALSE)
binned_data <- create_data_bins(rawdata, bins = bins)
segreg_test <- test_segregation(binned_data)
no_dist <- select_segreg(segreg_test, distorted = FALSE, numbers = TRUE)
LOD_sug <- suggest_lod(binned_data)
twopts <- rf_2pts(binned_data, LOD = LOD_sug, max.rf = 0.4)
mark_no_dist <- make_seq(twopts, c(no_dist))
LGs <- group(mark_no_dist)

LGs

bins
# There are 487 bins

# get 15 linkage groups. and three unlinked markers.

# do initial ordering of markers.
set_map_fun("kosambi")
LG01 <- make_seq(LGs, 1)
LG02 <- make_seq(LGs, 2)
LG03 <- make_seq(LGs, 3)
LG04 <- make_seq(LGs, 4)
LG05 <- make_seq(LGs, 5)
LG06 <- make_seq(LGs, 6)
LG07 <- make_seq(LGs, 7)
LG08 <- make_seq(LGs, 8)
LG09 <- make_seq(LGs, 9)
LG10 <- make_seq(LGs, 10)
LG11 <- make_seq(LGs, 11)
LG12 <- make_seq(LGs, 12)
LG13 <- make_seq(LGs, 13)
LG14 <- make_seq(LGs, 14)
LG15 <- make_seq(LGs, 15)
LG01_ord <- order_seq(LG01, n.init = 5, THRES = 3)
LG02_ord <- order_seq(LG02, n.init = 5, THRES = 3)
LG03_ord <- order_seq(LG03, n.init = 5, THRES = 3)
LG04_ord <- order_seq(LG04, n.init = 5, THRES = 3)
LG05_ord <- order_seq(LG05, n.init = 5, THRES = 3)
LG06_ord <- order_seq(LG06, n.init = 5, THRES = 3)
LG07_ord <- order_seq(LG07, n.init = 5, THRES = 3)
LG08_ord <- order_seq(LG08, n.init = 5, THRES = 3)
LG09_ord <- order_seq(LG09, n.init = 5, THRES = 3)
LG10_ord <- order_seq(LG10, n.init = 5, THRES = 3)
LG11_ord <- order_seq(LG11, n.init = 5, THRES = 3)
LG12_ord <- order_seq(LG12, n.init = 5, THRES = 3)
LG13_ord <- order_seq(LG13, n.init = 5, THRES = 3)
LG14_ord <- order_seq(LG14, n.init = 5, THRES = 3)
LG15_ord <- order_seq(LG15, n.init = 5, THRES = 3)
LG01_all <- make_seq(LG01_ord, "force")
LG02_all <- make_seq(LG02_ord, "force")
LG03_all <- make_seq(LG03_ord, "force")
LG04_all <- make_seq(LG04_ord, "force")
LG05_all <- make_seq(LG05_ord, "force")
LG06_all <- make_seq(LG06_ord, "force")
LG07_all <- make_seq(LG07_ord, "force")
LG08_all <- make_seq(LG08_ord, "force")
LG09_all <- make_seq(LG09_ord, "force")
LG10_all <- make_seq(LG10_ord, "force")
LG11_all <- make_seq(LG11_ord, "force")
LG12_all <- make_seq(LG12_ord, "force")
LG13_all <- make_seq(LG13_ord, "force")
LG14_all <- make_seq(LG14_ord, "force")
LG15_all <- make_seq(LG15_ord, "force")


#########################################################################
# Create files for removing redundant markers                           #
#########################################################################

# need to restart R!!!
options(max.print = 30000)
sink( file = "malebins.txt")
bins
closeAllConnections()


library(onemap)
initial_maps <- list(LG01_all, LG02_all, LG03_all, LG04_all, LG05_all, LG06_all, LG07_all, LG08_all, LG09_all, LG10_all, LG11_all, LG12_all, LG13_all, LG14_all, LG15_all)
sink(file = "firstmalemaps.txt")
initial_maps
closeAllConnections()



#########################################################################
# Refine LG01                                                           #
#########################################################################

rf_graph_table(LG01_all, inter = FALSE, main = "LG01 - initial map")

#remove redundant markers
LG01_test_seq <- drop_marker(LG01_all, c(288,286,285,282,239,238,236,233,232,229,224,5,7,10,11,14,380))
(LG01_test_map <- map(LG01_test_seq))
# log likelihood now -435.3354

rf_graph_table(LG01_all, inter = FALSE, main = "LG01 - initial map")


# 8, 382, 359 single marker bin with missing data
# 383, 366,290 single marker bin out of ordre with contig
LG01_test_seq <- drop_marker(LG01_test_seq, c(382,3, 383,8,366,359, 290))
(LG01_test_map <- map(LG01_test_seq))
rf_graph_table(LG01_test_map, inter = FALSE, main = "LG01 - initial map")
#likelihood now -313.0943


# reposition 482 and 365
LG01_test_seq <- drop_marker(LG01_test_seq, c(482,365))
(LG01_test_map <- map(LG01_test_seq))

LG01_try <- try_seq(LG01_test_map, 482)
LG01_try
LG01_test_map <- make_seq(LG01_try,1)

LG01_try <- try_seq(LG01_test_map, 365)
LG01_try
LG01_test_map <- make_seq(LG01_try,2)
rf_graph_table(LG01_test_map, inter = FALSE, main = "LG01 - initial map")

# looks okay.


LG01_final <- LG01_test_map





#########################################################################
# Refine LG02                                                           #
#########################################################################

LG02_all

#remove redundant markers
LG02_test_seq <- drop_marker(LG02_all, c(455,406,404,16,17,19,22,23,25,281,277,266,264))
(LG02_test_map <- map(LG02_test_seq))
# log likelihood now still -531.8291

rf_graph_table(LG02_test_map, inter = FALSE, main = "LG02")

# 218, 219, 220, 270, 33, 485 single marker bin with missing data
# 29, 32 single marker bin out of ordre with contig
LG02_test_seq <- drop_marker(LG02_test_seq, c(485,29, 218, 219, 220, 270, 32, 33))
(LG02_test_map <- map(LG02_test_seq))
rf_graph_table(LG02_test_map, inter = FALSE, main = "LG01 - initial map")
#likelihood now -338.1013

# 279 single marker bin that is just in the wrong place
LG02_test_seq <- drop_marker(LG02_test_seq, c(279))
(LG02_test_map <- map(LG02_test_seq))
rf_graph_table(LG02_test_map, inter = FALSE, main = "LG01 - initial map")



LG02_final <- LG02_test_map



#########################################################################
# Refine LG03                                                           #
#########################################################################

LG03_all


#remove redundant markers
LG03_test_seq <- drop_marker(LG03_all, c(387,389,392,394,143,145,146,151,152,40,42,46))
(LG03_test_map <- map(LG03_test_seq))
# log likelihood now still -280.485

rf_graph_table(LG03_test_map, inter = FALSE, main = "LG03")


#marker 41 single marker out of order with contig.
LG03_test_seq <- drop_marker(LG03_test_map, c(41))
(LG03_test_map <- map(LG03_test_seq))
# now -271.7887
rf_graph_table(LG03_test_map, inter = FALSE, main = "LG03")



LG03_final <- LG03_test_map

#########################################################################
# Refine LG04                                                           #
#########################################################################

LG04_all
#likelihood of this map is -499.4446

#remove redundant markers
LG04_test_seq <- drop_marker(LG04_all, c(62,223,156,154))
(LG04_test_map <- map(LG04_test_seq))
# log likelihood now -499.4405

rf_graph_table(LG04_test_map, inter = FALSE, main = "LG04")

#marker 48, 59 single marker bin with missind data. 
#marker 50, 466, 221  single marker bins, out of order with contig. 
#markers 379 and 295 each have two markers, one with a missing datapoint. They are both out of order with the contig (and far from each other)
LG04_test_seq <- drop_marker(LG04_test_map, c(59, 50, 466, 221, 295, 379, 48))
(LG04_test_map <- map(LG04_test_seq))

rf_graph_table(LG04_test_map, inter = FALSE, main = "LG04")


#483 makes me uneasy. It's a single marker bin and the only variant from this contig in the entire dataset. I am going to remove it. 
LG04_test_seq <- drop_marker(LG04_test_map, c(483))
(LG04_test_map <- map(LG04_test_seq))
rf_graph_table(LG04_test_map, inter = FALSE, main = "LG04")


LG04_final <- LG04_test_map


#########################################################################
# Refine LG05                                                           #
#########################################################################

LG05_all
# log likelihood -419.3529

#no redundant markers

# 970, 432, 439, 692,  all single marker with missing data.
# dropped them
LG05_test_seq <- drop_marker(LG05_all, c(197,199,195,192,189,187,65,68))
(LG05_test_map <- map(LG05_test_seq))
# log likelihood now -419.3443

rf_graph_table(LG05_test_map, inter = FALSE, main = "LG05")


# 71 single marker bin with missing data 
# 460 66, 193 single marker bin out of order with rest of contig. 
LG05_test_seq <- drop_marker(LG05_test_map, c(71, 193, 66, 460))
(LG05_test_map <- map(LG05_test_seq))
rf_graph_table(LG05_test_map, inter = FALSE, main = "LG05")


LG05_final <- LG05_test_map


#########################################################################
# Refine LG06                                                           #
#########################################################################

LG06_all


#remove redundant markers
LG06_test_seq <- drop_marker(LG06_all, c(274,75,79,81,83,88,91,92,95))
(LG06_test_map <- map(LG06_test_seq))
# log likelihood now -391.2847

rf_graph_table(LG06_test_map, inter = FALSE, main = "LG06")

# 77, 80 single marker bin with missing data
# 98, 89, 85, 76, 86 single marker bin out of place with rest of contig. 
LG06_test_seq <- drop_marker(LG06_test_map, c(80, 77, 76, 86, 85, 89, 98))
(LG06_test_map <- map(LG06_test_seq))
rf_graph_table(LG06_test_map, inter = FALSE, main = "LG06", graph.LOD = FALSE)

LG06_final <- LG06_test_map


#########################################################################
# Refine LG07                                                           #
#########################################################################

LG07_all


#remove redundant marker
LG07_test_seq <- drop_marker(LG07_all, c(99,102,105,107,108,204))
(LG07_test_map <- map(LG07_test_seq))
# log likelihood now -264.7171

rf_graph_table(LG07_test_map, inter = FALSE, main = "LG07", graph.LOD = FALSE)

# 113 single marker bin out of order with rest of contig.
LG07_test_seq <- drop_marker(LG07_test_map, c(113))
(LG07_test_map <- map(LG07_test_seq))
rf_graph_table(LG07_test_map, inter = FALSE, main = "LG07", graph.LOD = FALSE)

LG07_final <- LG07_test_map

#########################################################################
# Refine LG08                                                           #
#########################################################################

LG08_all


#remove redundant marker
LG08_test_seq <- drop_marker(LG08_all, c(426,424,421,400))
(LG08_test_map <- map(LG08_test_seq))
# log likelihood now -244.6206

rf_graph_table(LG08_test_map, inter = FALSE, main = "LG08", graph.LOD = FALSE)





LG08_final <- LG08_test_map

#########################################################################
# Refine LG09                                                           #
#########################################################################

LG09_all


#remove redundant marker
LG09_test_seq <- drop_marker(LG09_all, c(170,169,166,164,163))
(LG09_test_map <- map(LG09_test_seq))
# log likelihood now -216.8302

rf_graph_table(LG09_test_map, inter = FALSE, main = "LG09", graph.LOD = FALSE)



# 122 single marker bin with missing data. 
# 123 single marker bin out of order with rest of contig.
LG09_test_seq <- drop_marker(LG09_test_map, c(122, 123))
(LG09_test_map <- map(LG09_test_seq))

rf_graph_table(LG09_test_map, inter = FALSE, main = "LG09", graph.LOD = FALSE)


# looks good
LG09_final <- LG09_test_map


#########################################################################
# Refine LG10                                                           #
#########################################################################

LG10_all


#remove redundant marker
LG10_test_seq <- drop_marker(LG10_all, c(467,446,445,464,462,335))
(LG10_test_map <- map(LG10_test_seq))
# log likelihood now -403.3496

rf_graph_table(LG10_test_map, inter = FALSE, main = "LG10", graph.LOD = FALSE)



# 139, 135 single marker bin with missing data. 
# 386 single marker bin out of order with rest of contig.
LG10_test_seq <- drop_marker(LG10_test_map, c(139, 135, 386))
(LG10_test_map <- map(LG10_test_seq))
# this map is now -307.3631
rf_graph_table(LG10_test_map, inter = FALSE, main = "LG10", graph.LOD = FALSE)

# 257 is single marker bin, but seems out of place with respect to the other markers. 
LG10_test_seq <- drop_marker(LG10_test_map, c(257))
(LG10_test_map <- map(LG10_test_seq))
# map now -297.791

LG10_try <- try_seq(LG10_test_map, 257)
LG10_try
# I will try putting it where the assembly says it should be.
LG10_test_map <- make_seq(LG10_try, 2)
# this looks better
LG10_test_map
# this map is -307.6331, which is very close to the original.  I will keep this.
rf_graph_table(LG10_test_map, inter = FALSE, main = "LG10", graph.LOD = FALSE)


# looks okay.
LG10_final <- LG10_test_map


#########################################################################
# Refine LG11                                                           #
#########################################################################

LG11_all


#remove redundant marker
LG11_test_seq <- drop_marker(LG11_all, c(261,175,314,312,395))
(LG11_test_map <- map(LG11_test_seq))
# log likelihood now -421.2185

rf_graph_table(LG11_test_map, inter = FALSE, main = "LG11", graph.LOD = FALSE)


# 303, 245, 248, 259, 315  single marker bin with missing data. 
# single marker bin out of order with rest of contig.
LG11_test_seq <- drop_marker(LG11_test_map, c(303, 245, 248, 259, 315))
(LG11_test_map <- map(LG11_test_seq))
rf_graph_table(LG11_test_map, inter = FALSE, main = "LG11", graph.LOD = FALSE)


# looks good
LG11_final <- LG11_test_map

#########################################################################
# Refine LG12                                                           #
#########################################################################

LG12_all


#remove redundant marker
LG12_test_seq <- drop_marker(LG12_all, c(331,330,325,322,321,319,316))
(LG12_test_map <- map(LG12_test_seq))
# log likelihood now -269.8378

rf_graph_table(LG12_test_map, inter = FALSE, main = "LG12", graph.LOD = FALSE)


# single marker bin with missing data. 
# 326, 327 single marker bin out of order with rest of contig.
LG12_test_seq <- drop_marker(LG12_test_map, c(326, 327))
(LG12_test_map <- map(LG12_test_seq))
rf_graph_table(LG12_test_map, inter = FALSE, main = "LG12", graph.LOD = FALSE)


# looks good
LG12_final <- LG12_test_map




#########################################################################
# Refine LG13                                                           #
#########################################################################

LG13_all


# no redundant markers
rf_graph_table(LG13_all, inter = FALSE, main = "LG13", graph.LOD = FALSE)


# 353 is single marker bin with  missing data
# 213, 351 is single marker bin out of order with contig
LG13_test_seq <- drop_marker(LG13_all, c(351, 353, 213))
(LG13_test_map <- map(LG13_test_seq))
rf_graph_table(LG13_test_map, inter = FALSE, main = "LG13", graph.LOD = FALSE)



# looks good
LG13_final <- LG13_test_map


#########################################################################
# Refine LG14                                                           #
#########################################################################

LG14_all


#remove redundant marker
LG14_test_seq <- drop_marker(LG14_all, c(367,369,372,373,296,298))
(LG14_test_map <- map(LG14_test_seq))
# log likelihood now -137.47.49

rf_graph_table(LG14_test_map, inter = FALSE, main = "LG14", graph.LOD = FALSE)


# looks good
LG14_final <- LG14_test_map



#########################################################################
# Refine LG15                                                           #
#########################################################################

LG15_all


#remove redundant marker
LG15_test_seq <- drop_marker(LG15_all, c(437,416,414,412,409,450,435,434,431))
(LG15_test_map <- map(LG15_test_seq))
# log likelihood now -382.3123

rf_graph_table(LG15_test_map, inter = FALSE, main = "LG15", graph.LOD = FALSE)

# 309, 432, 448, 449, 473 is single marker bin with missing data
# 441 is single marker bin out of order with contig
LG15_test_seq <- drop_marker(LG15_test_map, c(448, 449, 441, 473, 432, 309))
(LG15_test_map <- map(LG15_test_seq))
rf_graph_table(LG15_test_map, inter = FALSE, main = "LG15", graph.LOD = FALSE)


# looks good
LG15_final <- LG15_test_map


########################################################################
# Write maps to a file then determine which contigs are present in which map                    
########################################################################


final_maps_not_in_order <- list(LG01_final, LG02_final, LG03_final, LG04_final, LG05_final, LG06_final, LG07_final, LG08_final, LG09_final, LG10_final, LG11_final, LG12_final, LG13_final, LG14_final, LG15_final)

write_map(map.list = final_maps_not_in_order, file.out = "final_male_maps_not_in_order.txt")


# now use this map file to "unbin" the markers and comput statistics on contig representation.

# one marker in LG1 should be dropped
LG01_test_seq <- drop_marker(LG01_final, c(355))
(LG01_test_map <- map(LG01_test_seq))
LG01_test_map
LG01_final <- LG01_test_map



# now I compared the contigs in each linkage group to the linkage groups from the female map and matched them up to ID the syntenic ones.

sLG01 <- LG05_final
sLG02 <- LG11_final
sLG03 <- LG04_final
sLG04 <- LG06_final
sLG05 <- LG10_final
sLG06 <- LG08_final
sLG07 <- LG02_final
sLG08 <- LG15_final
sLG09 <- LG13_final
sLG10 <- LG09_final
sLG11 <- LG01_final
sLG12 <- LG03_final
sLG13 <- LG12_final
sLG14 <- LG07_final
sLG15 <- LG14_final


syntenic_linkage_groups <- list(sLG01, sLG02, sLG03, sLG04, sLG05, sLG06, sLG07, sLG08, sLG09, sLG10, sLG11, sLG12, sLG13, sLG14, sLG15)
write_map(map.list = syntenic_linkage_groups, file.out = "male_syntenic_linkage_groups.txt")






########################################################################
# Drawing maps                                                         #
########################################################################

draw_map2(syntenic_linkage_groups, output = "syntenic_linkage_groups.png", group.names = c("LG1", "LG2","LG3","LG4", "LG5", "LG6", "LG7", "LG8", "LG9", "LG10", "LG11", "LG12", "LG13", "LG14", "LG15"), space = 1)
draw_map2(syntenic_linkage_groups, output = "syntenic_linkage_groups.png", group.names = c("LG1", "LG2","LG3","LG4", "LG5", "LG6", "LG7", "LG8", "LG9", "LG10", "LG11", "LG12", "LG13", "LG14", "LG15"), space = 1)
draw_map2(syntenic_linkage_groups, output = "syntenic_linkage_groups.png", group.names = c("LG1", "LG2","LG3","LG4", "LG5", "LG6", "LG7", "LG8", "LG9", "LG10", "LG11", "LG12", "LG13", "LG14", "LG15"), tag = "all")



