# load the data
library(qtl)
femaledata <- read.cross(format = "csvr", file = "femaledata.rqtl.with.phenotypes.csvr")
maledata <- read.cross(format = "csvr", file = "maledata.rqtl.with.phenotypes.csvr")

# analyze the female dataset
female_genoprob <- calc.genoprob(femaledata, map.function = "kosambi")
female_binary_hk <- scanone(female_genoprob, pheno.col = 2, model = "binary", method = "hk")
female_binary_hk_perm <- scanone(female_genoprob, pheno.col = 2, model = "binary", method = "hk", n.perm = 1000, perm.Xsp = 1)
summary(female_binary_hk_perm)
plot(female_binary_hk, gap = 30, ylim = c(0,24))
abline(h = 3.02, col = "red")
png("female_binary_hk.png")
plot(female_binary_hk, gap = 30, ylim = c(0,24))
abline(h = 3.07, col = "red")
dev.off()

# analyze the male dataset
# of the three methods availabe for binary traits, "hk" seems best
male_genoprob <- calc.genoprob(maledata, map.function = "kosambi")
male_binary_hk <- scanone(male_genoprob, pheno.col = 2, model = "binary", method = "hk")
male_binary_hk_perm <- scanone(male_genoprob, pheno.col = 2, model = "binary", method = "hk", n.perm = 1000, perm.Xsp = 1)
summary(male_binary_hk_perm)
plot(male_binary_hk, gap = 30, ylim = c(0,21))
abline(h = 2.71, col = "red")
png("male_binary_hk.png")
plot(male_binary_hk, gap = 30, ylim = c(0,24))
abline(h = 2.71, col = "red")
dev.off()


# show chr 4 in the male
png("male_binary_hk.chr4.png")
plot(male_binary_hk, gap = 20, ylim = c(0,24), chr = 4)
abline(h = 2.71, col = "red")
dev.off()


# generate figures for Tutzing
# FEMALE FIRST
# figure out what p-values to display
summary(female_binary_hk_perm, alpha = c(0.05, 0.01, 0.001, 0.00000000000000000000000000000001))

# draw the plot with p = 0.05
png(filename = "female_binary_hk_allChr.png", width = 2000, height = 525, units = "px")
plot(female_binary_hk, gap = 30, ylim = c(0,24), bandcol = "gray90", lwd = 2)
abline(h = 3.03, col = "red", lwd = 2)
dev.off()

# MALE
# figure out what p-values to display
summary(male_binary_hk_perm, alpha = c(0.05, 0.01, 0.001, 0.00000000000000000000000000000001))

# draw the plot with p = 0.05
png(filename = "male_binary_hk_allChr.png", width = 2000, height = 525, units = "px")
plot(male_binary_hk, gap = 30, ylim = c(0,24), bandcol = "gray90", lwd = 2)
abline(h = 2.71, col = "red", lwd = 2)
dev.off()



################################################
# Sex changers
################################################


## See whether there's any signal on sex-changers
female_binary_hk_sex_change <- scanone(female_genoprob, pheno.col = 3, model = "binary", method = "hk")
plot(female_binary_hk_sex_change)
female_binary_hk_sex_change_perm <- scanone(female_genoprob, pheno.col = 3, model = "binary", method = "hk", n.perm = 1000, perm.Xsp = 1)
summary(female_binary_hk_perm)

male_binary_hk_sex_change <- scanone(male_genoprob, pheno.col = 3, model = "binary", method = "hk")
plot(male_binary_hk_sex_change)
male_binary_hk_sex_change_perm <- scanone(male_genoprob, pheno.col = 3, model = "binary", method = "hk", n.perm = 1000, perm.Xsp = 1)
summary(male_binary_hk_sex_change_perm)









## See whether there's any signal on CERTAIN sex-changers
female_binary_hk_certain_sex_change <- scanone(female_genoprob, pheno.col = 4, model = "binary", method = "hk")
plot(female_binary_hk_certain_sex_change)
female_binary_hk_certain_sex_change_perm <- scanone(female_genoprob, pheno.col = 4, model = "binary", method = "hk", n.perm = 1000, perm.Xsp = 1)
summary(female_binary_hk_certain_sex_change_perm)

male_binary_hk_certain_sex_change <- scanone(male_genoprob, pheno.col = 4, model = "binary", method = "hk")
plot(male_binary_hk_certain_sex_change)
male_binary_hk_certain_sex_change_perm <- scanone(male_genoprob, pheno.col = 4, model = "binary", method = "hk", n.perm = 1000, perm.Xsp = 1)
summary(male_binary_hk_certain_sex_change_perm)





##################################################################
# Figures for the paper
##################################################################


# female plot
summary(female_binary_hk_perm, alpha = c(0.05, 0.00001))
postscript(file = "female_all_chr.eps")
plot(female_binary_hk, gap = 30, ylim = c(0,21))
abline(h = 3.02, col = "red")
abline(h = 5.09, col = "blue")
dev.off()


# female plot
summary(male_binary_hk_perm, alpha = c(0.05, 0.00001))
postscript(file = "male_all_chr.eps")
plot(male_binary_hk, gap = 30, ylim = c(0,21))
abline(h = 2.71, col = "red")
abline(h = 4.84, col = "blue")
dev.off()


# male chr 4
postscript("male_chr4.eps")
plot(male_binary_hk, gap = 20, ylim = c(0,21), chr = 4)
abline(h = 2.71, col = "red")
abline(h = 4.84, col = "blue")
dev.off()
